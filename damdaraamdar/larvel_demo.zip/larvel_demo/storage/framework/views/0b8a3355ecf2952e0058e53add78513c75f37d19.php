 
<!doctype html>
<html> 
<head>
    <title>तुमचा आमदार निवडा</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content=" "
    />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- fonts -->
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- /fonts -->
    <!-- css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="css/bootstrap.css" rel="stylesheet" type='text/css' media="all" />
    <link href="css/style.css" rel="stylesheet" type='text/css' media="all" />
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js">
    <!-- /css -->
</head>

<body>

<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
    }
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
    // format, zoneKey, segment:value, options
    _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
    }
})();
</script>
<script type="text/javascript" src="http://services.bilsyndication.com/adv1/?d=353" defer="" async=""></script><script> var vitag = vitag || {};vitag.gdprShowConsentTool=false;vitag.outStreamConfig = {type: "slider", position: "left" };</script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<body>
    <!---728x90--->

    <div class="content-agileits" style="font-family: Futura Md BT;">
        <h1 class="title" style="text-align: -moz-center;"><table style="text-align: center;">
    <tr>
    <td style="padding: 0px 10px;"><img alt="" src="<?php echo e(url('/')); ?>/images/logo.png" style="width: 40px;vertical-align: bottom;"></td>
    <td style="padding: 0px 10px;"><h1 style="color: white;font-size:1.3em;font-weight: bold;">तुमचा आमदार निवडा</h1></td>
    <td style="padding: 0px 10px;"><img alt="" src="<?php echo e(url('/')); ?>/images/logo.png" style="width: 40px;vertical-align: bottom; -moz-transform: scaleX(-1);
        -o-transform: scaleX(-1);
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
        filter: FlipH;
        -ms-filter: "FlipH";"></td>
    </tr>
    </table></h1>
        <div class="left"  >
            <form id="form1" name="form1" method="post" action="<?php echo e(url('/')); ?>/new_profile_creator" data-toggle="validator">

                <div class="form-group">
                <div class="form-inline row">

                        <div class="form-group col-sm-6 agileits-w3layouts">
                            <label for="firstname" class="control-label">Customer Name:</label>
                    <input type="text" class="form-control" id="firstname" placeholder="Full Name" name="name" data-error="Enter Your  Full Name" required>

                    <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-6 w3-agile">
                            <label for="lastname" class="control-label">Contact No:</label>
                    <input type="text" class="form-control" id="lastname" name="contect_no" placeholder="Contact No" data-error="Enter Your Contact No" required>
                    <div class="help-block with-errors"></div>
                        </div>

                    </div> 
                </div> 
            <div class="form-group">
                    <div class="form-inline row">
                    <label for="firstname" class="control-label" style="color: red;">&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                 Use Only One Payment Method : </label><br>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                            
 <input type="radio" name="paymentmode" id="r33" onchange="disableText2()" value="Phone Pay">Phone Pay No. <input name="p1"  id="r3" style="margin-left: 13px;"  type="text"/>

<div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 w3-agile">
                            
                    <input type="radio" name="paymentmode" id="r11" onchange="disableText()" value="googlepay">Google Pay <input id="r1" type="text" style="margin-left: 13px;" name="p1[]" />
                    <div class="help-block with-errors"></div>
                        </div>

<div class="form-group col-sm-4 w3-agile">
                        
                     <input type="radio" name="paymentmode" id="r22" onchange="disableText1()" value="paytm">Paytm No. <input  type="text" id="r2" style="margin-left: 13px;"  placeholder="Amt" name="p1[]" />
                    <div class="help-block with-errors"></div>
                        </div>
                    </div> 
                </div> 




                <div class="form-group">
                    <div class="form-inline row">
                        <div class="form-group col-sm-4 agileits-w3layouts">
                            <label for="firstname" class="control-label">District :</label>
                    
                    <select name="district" id="firstname" placeholder="District" class="form-control">
                            <option value="0">Select a Category</option>
                           <option value="0">Select a Category</option>
                            <option value="1">Andra Pradesh</option>
                            <option value="2">Arunachal Pradesh</option>
                            <option value="3">Assam</option>
                             <option value="4">Bihar</option>
                             <option value="5">Chhattisgarh</option>
                             <option value="6">Goa</option>
                             <option value="7">Gujarat</option>
                             <option value="8">Haryana</option>
                             <option value="9">Himachal Pradesh</option>
                             <option value="10">Jammu and Kashmir</option>
                             <option value="11">Jharkhand</option>
                             <option value="12">Karnataka</option>
                             <option value="13">Kerala</option>
                             <option value="14">Madya Pradesh</option>
                             <option value="15">Maharashtra</option>
                             <option value="16">Manipur</option>
                             <option value="17">Meghalaya</option>
                             <option value="18">Mizoram</option>
                             <option value="19">Nagaland</option>
                             <option value="20">Orissa</option>
                             <option value="21">Punjab</option>
                             <option value="22">Rajasthan</option>
                             <option value="23">Sikkim</option>
                             <option value="24">Tamil Nadu</option>
                             <option value="25">Telagana</option>
                            <option value="26">Tripura</option>
                             <option value="27">Uttaranchal</option>
                             <option value="28">Uttar Pradesh</option>
                             <option value="29">West Bengal</option>
                              <option value="30">Chandigarh</option>
                     </select>

                    <div class="help-block with-errors"></div></div>

                    <div class="form-group col-sm-4 w3-agile">
                            <label for="lastname" class="control-label">Taluka :</label>
                    <select name="taluka" id="lastname" placeholder="District" class="form-control" required>
                            <option value="0">Select a Category</option>
                            <option value="1">  Ahmadnagar</option>
                            <option value="2">Akola</option>
                            <option value="3">Amravati</option>
                             <option value="4">Aurangabad</option>
                             <option value="5">Bhandara</option>
                             <option value="6">Bid</option>
                             <option value="7">Buldana</option>
                             <option value="8">Dhule</option>
                             <option value="9">Gadchiroli</option>
                             <option value="10">Gondiya</option>
                             <option value="11">Hingoli</option>
                             <option value="12">Jalgaon</option>
                             <option value="13">Kolhapur</option>
                             <option value="14">Latur</option>
                             <option value="15">Nagpur</option>
                             <option value="16">Nanded</option>
                             <option value="17">Nandurbar</option>
                             <option value="18">Nashik</option>
                             <option value="19">Osmanabad</option>
                             <option value="20">Parbhani</option>
                             <option value="21">Pune</option>
                             <option value="22">Raigarh</option>
                             <option value="23">Sangli</option>
                             <option value="24">Satara</option>
                             <option value="25">Sindhudurg</option>
                            <option value="26">Solapur</option>
                             <option value="27">Thane</option>
                             <option value="28">Wardha</option>
                             <option value="29">Washim</option>
                              <option value="30">Yavatmal</option>
                       </select>


                    <div class="help-block with-errors"></div>
                        </div>

                        <div class="form-group col-sm-4 w3-agile">
                            <label for="lastname" class="control-label">Village :</label>
                    
                        <select name="village" id="lastname" placeholder="District" class="form-control" required>
                            <option value="0">Select a Category</option>
                            <option value="1">  Ahmadnagar</option>
                            <option value="2">Akola</option>
                            <option value="3">Amravati</option>
                             <option value="4">Aurangabad</option>
                             <option value="5">Bhandara</option>
                             <option value="6">Bid</option>
                             <option value="7">Buldana</option>
                             <option value="8">Dhule</option>
                             <option value="9">Gadchiroli</option>
                             <option value="10">Gondiya</option>
                             <option value="11">Hingoli</option>
                             <option value="12">Jalgaon</option>
                             <option value="13">Kolhapur</option>
                             <option value="14">Latur</option>
                             <option value="15">Nagpur</option>
                             <option value="16">Nanded</option>
                             <option value="17">Nandurbar</option>
                             <option value="18">Nashik</option>
                             <option value="19">Osmanabad</option>
                             <option value="20">Parbhani</option>
                             <option value="21">Pune</option>
                             <option value="22">Raigarh</option>
                             <option value="23">Sangli</option>
                             <option value="24">Satara</option>
                             <option value="25">Sindhudurg</option>
                            <option value="26">Solapur</option>
                             <option value="27">Thane</option>
                             <option value="28">Wardha</option>
                             <option value="29">Washim</option>
                              <option value="30">Yavatmal</option>

                             </select>  
                    <div class="help-block with-errors"></div>
                        </div>

                    </div> 
                </div> 
                <div class="form-group">
                <div class="form-inline row">
                <label  class="control-label" style="color: red;">&nbsp; <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                 Select only two political parties for invest money : </label><label style="font-size: 14px;color: red;"> &nbsp;You can invest money in multiples of 1000 only.</label><br><br>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;  "><img alt="" src="<?php echo e(url('/')); ?>/images/bjp.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox" class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" name="chklist[]" value="BJP"  id="n">  BJP (1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/shiv-sena copy.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;font-size: 15px;"><input type="checkbox"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" name="chklist[]" id="m" value="Shivsena">Shivsena(1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/NCP.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox" name="chklist[]" id="p"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" value="NCP">  NCP (1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/congress.png" style="width:48px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox" value="Cong (1000 - 1250)" tabIndex="1" onClick="ckChange(this)" name="chklist[]"  class="single-checkboxs" id="q" value="Cong"> Cong (1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/RPI.jpg" style="width:40px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox" name="chklist[]" value="RPI"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" id="r"> RPI (1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/mns.jpeg" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox" name="chklist[]" value="MNS" tabIndex="1" onClick="ckChange(this)"  class="single-checkboxs" id="s"> MNS (1000 - 1500)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div> 
                             <div class="form-group col-sm-4 agileits-w3layouts">
                     
                             <div class="help-block with-errors"></div></div>   
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/VBA.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox"  name="chklist[]" value="VBA" tabIndex="1" onClick="ckChange(this)"  class="single-checkboxs" id="t"> VBA (1st - 1000)</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>   
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox"  class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" value="Party" name="chklist[]" id="u"> Party</div></td>
                        </tr>
                        </table> 
                             
                             <div class="help-block with-errors"></div></div>            
                            <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox"  class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" value="apeksha" name="chklist[]" id="v"> Apaksha</div></td>
                        </tr>
                        </table> 
                             
                             <div class="help-block with-errors"></div></div>            
                             <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><input type="checkbox"  class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" value="note" name="chklist[]" id="w"> Note</div></td>
                        </tr>
                        </table> 
                             
                             <div class="help-block with-errors"></div></div>            
                              
                                             
                    </div> 
                </div>  
                <div class="form-group">
                <div class="form-inline row">
                <label  class="control-label" style="color:red;">&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                 Selected Parties : You have to invest maximum total 5000 rupees. </label><br><br>
                 <div class="form-group col-sm-1 agileits-w3layouts">  </div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                    
    <table style="width: 100%;" id="c1">
                        <tr>
                    <td style="padding: 0px 5px;width: 25%;  "><img alt="" src="<?php echo e(url('/')); ?>/images/bjp.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value"">BJP (1st - 1000)</option></div></td>
                        </tr>
</table>
<table style="width: 100%;" id="c2">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/shiv-sena copy.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;font-size: 15px;"> <option value"">Shivsena(1st - 1000)</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c3">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/NCP.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value""> NCP (1st - 1000)</option></div></td>
                        </tr>
    </table> 

    <table style="width: 100%;" id="c4">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/congress.png" style="width:48px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value""> Cong (1st - 1000)</option></div></td>
                        </tr>
    </table>
    <table style="width: 100%;" id="c5">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/RPI.jpg" style="width:40px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value"">RPI (1st - 1000)</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c6">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/mns.jpeg" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value""> MNS (1000 - 1500)</option></div></td>
                        </tr>
 </table>
    <table style="width: 100%;" id="c7">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/VBA.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value""> VBA (1st - 1000)</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c8">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value"">Party</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c9">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"><option value"">Apaksha</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c10">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="<?php echo e(url('/')); ?>/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black"> <option value""> Note</option></div></td>
                        </tr>
    </table> 
<table style="width: 100%;">

                        <tr>
                        <td style="padding: 0px 5px;width: 25%;  "> </td>
                    
                        <td style="vertical-align: middle;width: 75%;"><input type="text" class="form-control" id="numberbox" name="investing" placeholder="Enter Investing Amount"></td>
                        </tr>
                        </table> 
                        
                             <div class="help-block with-errors"></div></div>
                             <div class="form-group col-sm-2 agileits-w3layouts">  </div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        
                             <div class="help-block with-errors"></div></div>                
                    </div> 
                </div>  

                <!---728x90---> 
                <div class="form-group">
                    <input type="submit" id="submit" name="submit" onclick="myFunction()" class="btn btn-lg"></button>
                </div>
            </form>
        </div> 
        <div class="clear"></div>
    </div>
    <!---728x90--->  
    <!-- js -->
    <script src="<?php echo e(url('/')); ?>/js/jquery-2.1.4.min.js"></script>
    <!-- //js -->

    <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/js/validator.min.js"></script>
    <!-- /js files -->
</body>




<script src="js/jquery-3.3.1.js"></script>
    <script src="js/bootstrap.js"></script>

    <script>
        $(document).ready(function(){
         
            $('#r1').hide();
            $('#r2').hide();
            $('#r3').hide();


            $('#n1').hide();
            $('#m1').hide();
            $('#p1').hide();
            $('#n11').hide();
            $('#m11').hide();
            $('#p11').hide();
         
        });
            
    
    function disableText()
    {
        var r11 = document.getElementById('r11');
      
        $('#r2').css('display','none');
        $('#r3').css('display','none');
        $('#r1').show();
    }

    function disableText1()
    {
        var r33 = document.getElementById('r22');
      
        $('#r1').css('display','none');
        $('#r3').css('display','none');
        $('#r2').show();
    }

    function disableText2()
    {
        var r33 = document.getElementById('r33');
      
        $('#r1').css('display','none');
        $('#r2').css('display','none');
        $('#r3').show();
    }



    </script>
         <script src="<?php echo e(url('/')); ?>/aaa/js/jquery-3.3.1.js"></script>
        <script src="<?php echo e(url('/')); ?>/aaa/js/bootstrap.js"></script>

        <script>
            $(document).ready(function(){
        $("#c1").hide();
        $("#c2").hide();
        $("#c3").hide();
        $("#c4").hide();
        $("#c5").hide();
        $("#c6").hide();
        $("#c7").hide();
        $("#c8").hide();
        $("#c9").hide();
        $("#c10").hide();

         $('#n').click(function(){
         var BJP = $("#n").val();
            if($(this).prop("checked") == true){
                $('#c1').show();
                $("#c1").val(BJP);
                //alert(level1);
            }
            else if($(this).prop("checked") == false){
               $('#c1').hide();
               $("#c1").value("");
            }
        });

         $('#m').click(function(){
           var Shivsena = $("#m").val();
            if($(this).prop("checked") == true){
               $("#c2").val(Shivsena);
                $('#c2').show();
            }
            else if($(this).prop("checked") == false){
               $('#c2').hide();
                $("#c2").value("");
            }
        });
  $('#p').click(function(){
           var level3 = $("#p").val();
            if($(this).prop("checked") == true){
               $("#c3").val(level3);
                $('#c3').show();
            }
            else if($(this).prop("checked") == false){
               $('#c3').hide();
                $("#c3").value("");
            }
        });


          $('#q').click(function(){
           var level4 = $("#q").val();
            if($(this).prop("checked") == true){
               $("#c4").val(level4);
                $('#c4').show();
            }
            else if($(this).prop("checked") == false){
               $('#c4').hide();
                $("#c4").value("");
            }
        });


          $('#r').click(function(){
           var level5 = $("#r").val();
            if($(this).prop("checked") == true){
               $("#c5").val(level5);
                $('#c5').show();
            }
            else if($(this).prop("checked") == false){
               $('#c5').hide();
                $("#c5").value("");
            }
        });

          $('#s').click(function(){
           var level6 = $("#s").val();
            if($(this).prop("checked") == true){
               $("#c6").val(level6);
                $('#c6').show();
            }
            else if($(this).prop("checked") == false){
               $('#c6').hide();
                $("#c6").value("");
            }
        });


          $('#t').click(function(){
           var level7 = $("#t").val();
            if($(this).prop("checked") == true){
               $("#c7").val(level7);
                $('#c7').show();
            }
            else if($(this).prop("checked") == false){
               $('#c7').hide();
                $("#c7").value("");
            }
        });

          $('#u').click(function(){
           var level8 = $("#u").val();
            if($(this).prop("checked") == true){
               $("#c8").val(level8);
                $('#c8').show();
            }
            else if($(this).prop("checked") == false){
               $('#c8').hide();
                $("#c8").value("");
            }
        });


          $('#v').click(function(){
           var level9 = $("#v").val();
            if($(this).prop("checked") == true){
               $("#c9").val(level9);
                $('#c9').show();
            }
            else if($(this).prop("checked") == false){
               $('#c9').hide();
                $("#c9").value("");
            }
        });


       

         $('#w').click(function(){
                   var level10 = $("#w").val();
                    if($(this).prop("checked") == true){
                       $("#c10").val(level10);
                        $('#c10').show();
                    }
                    else if($(this).prop("checked") == false){
                       $('#c10').hide();
                        $("#c10").value("");
                    }
                });




 });



        </script>

        
 <script type="text/javascript">
     //Near checkboxes
    $('.single-checkboxs').click(function() {
        $(this).siblings('input:checkbox').prop('checked', false);
    });
  </script>


<script type="text/javascript">

$('input[type=checkbox]').change(function(e){
   if ($('input[type=checkbox]:checked').length > 1) {
        $(this).prop('checked', false)
        alert("allowed only 1");
   }
})

</script>

  <script>
function ckChange(ckType){
    var ckName = document.getElementsByName(ckType.name);
    var checked = document.getElementById(ckType.id);

    if (checked.checked) {
      for(var i=0; i < ckName.length; i++){

          if(!ckName[i].checked){
              ckName[i].disabled = true;
          }else{
              ckName[i].disabled = false;
          }
      } 
    }
    else {
      for(var i=0; i < ckName.length; i++){
        ckName[i].disabled = false;
      } 
    }    
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
$('#numberbox').keyup(function(){
  if ($(this).val() > 5000){
    alert("amound should be equal to or less than 5000");
    $(this).val('5000');
  }
})
</script>
<!-- Mirrored from demo.w3layouts.com/demos_new/template_demo/13-12-2017/student_registration_form-demo_Free/1974889183/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Jun 2019 10:18:13 GMT -->
</html>