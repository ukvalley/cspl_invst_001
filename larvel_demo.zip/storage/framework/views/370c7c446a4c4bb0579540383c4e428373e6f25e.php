                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Payout Statement</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/customer/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Payout Statement</a>
                        </li>
                        <li class="active">Growth Withdrawal</li>
                      </ol>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              <div class="row">
                <input type="hidden" id="total_a" name="total_a" value="<?php echo e($growth_income-$withdrawal); ?>">
                <div class="col s12 m8" style="align-content: center;">
                  <form id="form" class="col s12" method="post" action="<?php echo e(url('/')); ?>/customer/growth_withdrawal_process" <?php /* data-parsley-validate="" */ ?>>
                      <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo e(csrf_field()); ?>

                      <div class="row">
                        <div class="input-field col s4">
                            <label>Growth Income</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"><?php echo e($growth_income); ?></label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4">
                            <label >Withdrawal</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"><?php echo e($withdrawal); ?></label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4" >
                            <label >Rejection Income</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                          <label style="color: #000;font-weight: bold;"> 0</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s4">
                            <label>Total Amount</label>
                        </div>
                        <div class="input-field col s4" style="float: right;">
                        <div style="margin-left: -30%">
                            <hr style="margin-right: 55%">
                          </div>
                          <label style="color: #000;font-weight: bold;"> <i class="fa fa-inr"></i> <?php echo e($growth_income-$withdrawal); ?></label>
                        </div>
                        <br><br><br>
                        <div class="input-field col s12">
                          <select id="level_income" name="level_income" data-parsley-required="true">
                              <option value="">Select Package</option>
                              <option value="1000">1000</option>
                              <option value="2000">2000</option>
                              <option value="3000">3000</option>
                              <option value="4000">4000</option>
                              <option value="5000">5000</option>
                              <option value="10000">10000</option>
                              <option value="15000">15000</option>
                              <option value="20000">20000</option>
                              <option value="25000">25000</option>
                            </select>
                            <label for="level_income">Package</label>
                           <span id="error_level_income" style="float: left;" class="parsley-required"></span>
                          <div class="input-field col s6">
                            <?php $status =  $growth_income-$withdrawal; ?>
                            <?php if($status=='0' && $withdrawal!='0'): ?>
                              <a href="<?php echo e(url('/customer/re_entry')); ?>" class="btn cyan waves-effect waves-light right" id="submit" name="submit">Package Renewal</a>
                            <?php endif; ?>
                          </div>
                          <div class="input-field col s6">
                            <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                          </div>
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function()
    {
      $("#form").submit(function()
      {
        var level_income = $('#level_income').val();
        var total_a      = $('#total_a').val();
        if(level_income=='')
        {
          $('#error_level_income').text('Please select amount');
          return false;
        }
        else if(parseInt(level_income)>parseInt(total_a))
        { 
          $('#error_level_income').text('Amount should not grater than total amount');
          return false;
        }
        else 
        {
          $('#error_level_income').text('');
        }
      });
    });
  </script>
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>