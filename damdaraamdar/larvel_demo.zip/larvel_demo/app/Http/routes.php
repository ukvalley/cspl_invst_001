<?php

Route::group(['middleware'=>['api']],function()
{

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


	/* -------------------------------------------------------------------------------------
	 Admin Routes Group :: Main group all route of admin will in this Group 
	---------------------------------------------------------------------------------------*/


	/*-------------------------------------------
		Admin Route starts Here
	--------------------------------------------*/



	
	
		Route::get('/profile_creator_new',						['as'=>'profile_creator_new',					'uses'=>'Admin\AdminController@profile_creator_new']);


	Route::post('/new_profile_creator',						['as'=>'new_profile_creator',					'uses'=>'Admin\AdminController@new_profile_creator']);

   // 	Route::post('/submit_utr',						['as'=>'submit_utr',					'uses'=>'Admin\AdminController@submit_utr']);

    
    Route::get('/thanks',					['as'=>'thanks',					'uses'=>'Admin\AdminController@thanks']);
	Route::get('/',						['as'=>'profile_creator_new',					'uses'=>'Admin\AdminController@profile_creator_new']);
	
	
  //Route::get('/',						['as'=>'submitss',					'uses'=>'Admin\AdminController@submitss']);

 
  Route::post('/submit_utr',						['as'=>'submit_utr',					'uses'=>'Admin\AdminController@submit_utr']);
	
	/*	Route::get('/', function () 
	{
		return redirect('https://damdaraamdar.com/profile_creator_new');
	    //return view('');submit_utr
	});*/

 Route::get('/views',					['as'=>'views',					'uses'=>'Admin\AdminController@views']);
});


/*	Route::get('/', function () 
	{
		return redirect('https://damdaraamdar.com/profile_creator_new');
	    //return view('');
	});*/

