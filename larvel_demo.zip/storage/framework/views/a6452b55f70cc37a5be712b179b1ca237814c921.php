                

<?php $__env->startSection('main_content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
                <?php $day = 20; $amount =0; $counter = 0; ?>
                <?php for($i =1; $i <= 20; $i++): ?>
                <?php 
                  $user = Sentinel::check();
                  $counter++;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                  if(date('l', strtotime($date))=='Saturday' || date('l', strtotime($date))=='Sunday')
                  {
                    $i--;
                    continue;
                    //$amount = $amount-400;
                  }
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day-1;
                  }
                  
                ?>
                <?php endfor; ?>
              <h3><?php echo e($amt =  4000-(200*(20-$day))); ?></h3>

             
              <?php if($amt==0): ?>
              <a href="<?php echo e(url('/')); ?>/admin/recommit?email=<?php echo e($user->email); ?>" class="btn bg-red">Recommitment</a>
              <?php else: ?>
               <p>Commitment</p>
              <?php endif; ?>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer"><?php echo e($day); ?> Day Left <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
                <?php
                 $user = Sentinel::check();
                 $count = \DB::table('transaction')->where(['reciver_id'=>$user->email])->count();
                ?>
              <h3><?php echo e($count*400); ?></sup></h3>

              <p>Level Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>400</h3>

              <p>Today's Growth Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
               <?php
                 $count1 = \DB::table('transaction')->where(['reciver_id'=>$user->email])->where(['date'=>date('Y-m-d')])->count();
                ?>
              <h3><?php echo e($count1*400); ?></h3>

              <p>Today's Work Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="row">
           
           
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Link Details(Give)</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body">
                    <?php foreach($data_trans as $key=>$value): ?>
            <?php $trans_user_data = \DB::table('users')->where(['email'=>$value->reciver_id])->first();
            if(empty($trans_user_data->user_name))
            {
              continue;
            }
            ?>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Link <?php echo e($key+1); ?>:</label>:
                       <a href="<?php echo e(url('/')); ?>/admin/view?id=<?php echo e(isset($trans_user_data->id) ? $trans_user_data->id : 'NA'); ?>"><?php echo e(isset($trans_user_data->user_name) ? $trans_user_data->user_name : "NA"); ?></a>
                    </div>
                  </div>
                   <?php endforeach; ?>
                </div>
              </div>
            </div>
            
            
            
            
            
            <?php if($user->joining_date!=null): ?>
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Link Details(Get)</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body">
                    <?php 
                        $get_trans = \DB::table('transaction')->where(['reciver_id'=>$user->email])->get();
                    ?>
                    <?php foreach($get_trans as $key=>$value): ?>
            <?php $trans_user_data = \DB::table('users')->where(['email'=>$value->sender_id])->first();
            if(empty($trans_user_data->user_name))
            {
              continue;
            }
            ?>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Link <?php echo e($key+1); ?>:</label>:
                       <a href="<?php echo e(url('/')); ?>/admin/view?id=<?php echo e(isset($trans_user_data->id) ? $trans_user_data->id : 'NA'); ?>"><?php echo e(isset($trans_user_data->user_name) ? $trans_user_data->user_name : "NA"); ?></a>
                    </div>
                  </div>
                   <?php endforeach; ?>
                </div>
              </div>
            </div>
            <?php endif; ?>
           
          </div>

        </section>
        <!-- /.Left col -->
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>