 
<!doctype html>
<html> 
<head>
    <title>महाराष्ट्राचा दमदार ओपेनियन पोल ा</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content=" "
    />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- fonts -->
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- /fonts -->
    <!-- css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="{{url('/')}}/css/bootstrap.css" rel="stylesheet" type='text/css' media="all" />
    <link href="{{url('/')}}/css/style.css" rel="stylesheet" type='text/css' media="all" />
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js">
    <!-- /css -->
</head>

<body>

<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
    }
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
    // format, zoneKey, segment:value, options
    _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
    }
})();
</script>
<script type="text/javascript" src="http://services.bilsyndication.com/adv1/?d=353" defer="" async=""></script><script> var vitag = vitag || {};vitag.gdprShowConsentTool=false;vitag.outStreamConfig = {type: "slider", position: "left" };</script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<body>
    <!---728x90--->

    <div class="content-agileits" style="font-family: Futura Md BT;">
        <h1 class="title" style="text-align: -moz-center;">
        <table style="text-align: center;">
    <tr>
    <td style="padding: 0px 10px;"><img alt="" src="{{url('/')}}/images/logo.png" style="width: 40px;vertical-align: bottom;"></td>
    <td style="padding: 0px 10px;"><h2 style="color: white;font-size:1.3em;font-weight: bold;">महाराष्ट्राचा दमदार ओपेनियन पोल</h2></td>
    
  
    <td style="padding: 0px 10px;"><img alt="" src="{{url('/')}}/images/logo.png" style="width: 40px;vertical-align: bottom; -moz-transform: scaleX(-1);
        -o-transform: scaleX(-1);
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
        filter: FlipH;
        -ms-filter: "FlipH";"></td>
    </tr>
    
    
   
    </table></h1>


     


    
        <div class="left"  style="background: rgba(0, 0, 0, 0.4);">
       <center> <h3 style="color: white;font-size:1.3em;font-weight: bold;">तर्क तुमचे बक्षिस आमचे </h3> </center> <br>
        <h6 style="color: white;font-size:1.3em;font-weight: bold;">निवडा तुमच्या आवडत्या पक्षाचा आमदार आणि जिंका .. </h6>
            <form id="form1" name="form1" method="post" action="{{url('/')}}/new_profile_creator" data-toggle="validator">



                <div class="form-group">
                
  <div class="form-group">
                <div class="form-inline row">
           
                       <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/mns.jpeg" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox" name="chklist[]" value="MNS" tabIndex="1" onClick="ckChange(this)"  class="single-checkboxs" id="s"> MNS</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div> 
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;  "><img alt="" src="{{url('/')}}/images/bjp.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox" class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" name="chklist[]" value="BJP"  id="n">  BJP</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/shiv-sena copy.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;font-size: 15px;background: #ffea06;"><input type="checkbox"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" name="chklist[]" id="m" value="Shivsena"> Shivsena</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/NCP.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox" name="chklist[]" id="p"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" value="NCP">NCP</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/congress.png" style="width:48px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox" value="Cong (1000 - 1250)" tabIndex="1" onClick="ckChange(this)" name="chklist[]"  class="single-checkboxs" id="q" value="Cong"> Cong</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/RPI.jpg" style="width:40px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox" name="chklist[]" value="RPI"  tabIndex="1" onClick="ckChange(this)" class="single-checkboxs" id="r"> RPI</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        
                             <div class="form-group col-sm-4 agileits-w3layouts">
                     
                             <div class="help-block with-errors"></div></div>   
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/VBA.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox"  name="chklist[]" value="VBA" tabIndex="1" onClick="ckChange(this)"  class="single-checkboxs" id="t"> VBA</div></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>   
                              
                            <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;background: #ffea06;"><input type="checkbox"  class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" value="apeksha" name="chklist[]" id="v"> Apaksha</div></td>
                        </tr>
                        </table> 
                             
                             <div class="help-block with-errors"></div></div>            
                             <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="checkbox"  class="single-checkboxs" tabIndex="1" onClick="ckChange(this)" value="note" name="chklist[]" id="w"> NOTA</div></td>
                        </tr>
                        </table> 
                             
                             <div class="help-block with-errors"></div></div>            
                              
                                             
                    </div> 
                </div>  
                <div class="form-group">
                <div class="form-inline row">
                <center><label  class="control-label" value="" style="color:#ffea06;font-size:20px;">&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                 
रजिस्ट्रेशन  फॉम नोंदणी करा .</label></center>
                 <div class="form-group col-sm-1 agileits-w3layouts">  </div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                    
    <table style="width: 100%;" id="c1">
                        <tr>
                    <td style="padding: 0px 5px;width: 25%;  "><img alt="" src="{{url('/')}}/images/bjp.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value"">BJP</option></div></td>
                        </tr>
</table>
<table style="width: 100%;" id="c2">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/shiv-sena copy.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;font-size: 15px;background: #ffea06;"> <option value"">Shivsena</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c3">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/NCP.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value""> NCP</option></div></td>
                        </tr>
    </table> 

    <table style="width: 100%;" id="c4">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/congress.png" style="width:48px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value""> Cong</option></div></td>
                        </tr>
    </table>
    <table style="width: 100%;" id="c5">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/RPI.jpg" style="width:40px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value"">RPI</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c6">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/mns.jpeg" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value""> MNS</option></div></td>
                        </tr>
 </table>
    <table style="width: 100%;" id="c7">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/VBA.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value""> VBA</option></div></td>
                        </tr>
    </table>  
    <table style="width: 100%;" id="c9">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;background: #ffea06;"><option value"">Apaksha</option></div></td>
                        </tr>
    </table> 
    <table style="width: 100%;" id="c10">
                        <tr>
                        <td style="padding: 0px 5px;width: 25%;"><img alt="" src="{{url('/')}}/images/a.png" style="width:45px;"></td><td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"> <option value""> NOTA</option></div></td>
                        </tr>
    </table> <br>
<table style="width: 100%;">

                        <tr>
                       
                        </tr>
                        </table> 
                        
                             <div class="help-block with-errors"></div></div>
                             <div class="form-group col-sm-2 agileits-w3layouts">  </div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        
                             <div class="help-block with-errors"></div></div>                
                    </div> 
                </div>  
                <div class="form-inline row">

                        <div class="form-group col-sm agileits-w3layouts">
                            <label for="firstname" class="control-label">Customer Name:</label>
                    <input type="text" class="form-control" id="firstname" placeholder="Full Name" name="name" data-error="Enter Your  Full Name" required>

                    <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm w3-agile">
                            <label for="lastname" class="control-label">Contact No:</label>
                    <input type="text" class="form-control" id="lastname" name="contect_no" placeholder="Contact No" data-error="Enter Your Contact No" required>
                   
                         <div class="help-block with-errors"></div></div>
                    <div class="form-group col-sm w3-agile">
                            <label for="refno" class="control-label">Refernces Mobile No:</label><br>
                    <input type="text" class="form-control" size="24" id="refno" name="refno" placeholder="Refernces Contact No">
                    <div class="help-block with-errors"></div>
                        </div>
                    </div> 
 
 
                    <div class="form-inline">
                         <div class="form-group col-sm-3 agileits-w3layouts">
                                    <label for="state" class="control-label">state :</label><br>
                    
                    <select name="state" id="state" placeholder="District" class="form-control" style="border: 1px solid #337ab7;">
                            <option value="0">Select a State</option>
                        
                            <option value="1">Maharashtra</option>
                            
                             
                     </select>
                    </div> 

                    
                        <div class="form-group col-sm-3 agileits-w3layouts">
                            <label for="district" class="control-label">District :</label><br>
                      <select name="district" id="district" placeholder="District" class="form-control" style="border: 1px solid #337ab7;">
                            <option value="0">Select a  district</option> 
                            <option value="1">Ahmednagar</option>
                            <option value="2">Akola</option>
                            <option value="3">Amravati</option>
                             <option value="4">Aurangabad</option>
                             <option value="5">Beed</option>
                             <option value="6">Bhandara</option>
                             <option value="7">Buldhana</option>
                             <option value="8">Chandrapur</option>
                             <option value="9">Dhule</option>
                             <option value="10">Gadchiroli</option>
                             <option value="11">Gondia</option>
                             <option value="12">Hingoli</option>
                             <option value="13">Jalgaon</option>
                             <option value="14">Jalna</option>
                             <option value="15">Kolhapur</option>
                             <option value="16">Latur</option>
                             <option value="17">Mumbai City</option>
                             <option value="18">Mumbai Suburban</option>
                             <option value="19">Nagpur</option>
                             <option value="20">Nanded</option>
                             <option value="21">Nandurbar</option>
                             <option value="22">Nashik</option>
                             <option value="23">Osmanabad</option>
                             <option value="24">Palghar</option>
                             <option value="25">Parbhani</option>
                            <option value="26">Pune</option>
                            <option value="27">Raigad</option>
                             <option value="28">Ratnagiri</option>
                             <option value="29">Sangli</option>
                              <option value="30">Satara</option>
                              <option value="31">Sindhudurg</option>
                             <option value="32">Solapur</option>
                             <option value="33">Wardha</option>
                              <option value="34">Washim</option>
                                <option value="35">Yavatmal</option>
                     </select>
</div>
                    <div class="help-block with-errors"></div>
                        <div class="form-group col-sm-3 w3-agile">
                            <label for="taluka" class="control-label">Taluka :</label>
                    <input type="text" class="form-control"  name="taluka" id="taluka" placeholder="Taluka" style="border: 1px solid #337ab7;" data-error="Enter Your Taluka" required>
                    <div class="help-block with-errors"></div>
                        </div>

                    <div class="help-block with-errors"></div>
                        <div class="form-group col-sm-3 w3-agile">
                            <label for="lastname" class="control-label">Village :</label>
                    <input type="text" class="form-control"  name="village" id="village" placeholder="Village" style="border: 1px solid #337ab7;" data-error="Enter Your Village" required>
                    <div class="help-block with-errors"></div>
                        </div>
                     
                       
                  </div>
              </div>       
   <div class="form-group">
     <label for="firstname" class="control-label" style="color: #ffea06;font-size:20px;">&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
               <b style="font-size:"20px">रेसिट्रेशन फी . </b></label><br>
                <div class="form-inline row">
           
                       <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                           
                        <td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="radio" name="range" value="140" class="chs" id="s">99Rs</div><label class="control-label">जिंकल्यास बक्षिसाची  रककम -140</lab</td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div> 
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                           
                        <td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 6px;color: black;background: #ffea06;"><input type="radio" class="chs"  name="range" value="700"  id="n">499Rs</div> <label class="control-label">जिंकल्यास बक्षिसाची  रककम -700</label></td>
                        </tr>
                        </table> 
                             <div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 agileits-w3layouts">
                        <table style="width: 100%;">
                        <tr>
                           
                        <td style="vertical-align: middle;width: 75%;"><div style="border: 1px solid #337ab7;padding: 10px 2px;color: black;font-size: 15px;background: #ffea06;"><input type="radio"  class="chs" name="range" id="m" value="1400">999Rs</div> <label class="control-label">जिंकल्यास बक्षिसाची  रककम -1400</label></td>
                        </tr>
                        </table> 
                            
                                             
                    </div> 



                    <script>
$(document).ready(function(){
    $('.check').click(function() {
        $('.check').not(this).prop('checked', false);
    });
});
</script>
                </div> 
                  
      <div class="form-group">
                    <div class="form-inline row">
                        <label for="firstname" class="control-label" style="color: #ffea06;font-size:20px;">&nbsp;&nbsp;&nbsp;<i class="fa fa-dot-circle-o" aria-hidden="true"></i>
               <b style="font-size:"20px">बक्षिसाची  रक्क्म कुठल्या अकाउंटला घ्यायला  आवडेल . </b></label><br><br>
                    
                        <div class="form-group col-sm-4 agileits-w3layouts">
                            
 <input type="radio" name="paymentmode" id="r33" onchange="disableText2()" style="text-color:white" value="Phone Pay"><b style="color:white">Phone Pay No.</b> <input name="p1"  id="r3" style="margin-left: 13px;color:black;"  type="text"/>

<div class="help-block with-errors"></div></div>
                        <div class="form-group col-sm-4 w3-agile">
                            
                    <input type="radio" name="paymentmode" id="r11" style="text-color:white" onchange="disableText()" value="googlepay"><b style="color:white">Google Pay</b><input id="r1" type="text" style="margin-left: 13px;color:black;" name="p1[]" />
                    <div class="help-block with-errors"></div>
                        </div>

<div class="form-group col-sm-4 w3-agile">
                        
                     <input type="radio" name="paymentmode" id="r22" style="text-color:white" onchange="disableText1()" value="paytm"><b style="color:white">Paytm No.</b> <input  type="text" id="r2" style="margin-left: 13px;color:black;"  placeholder="Amt" name="p1[]" />
                    <div class="help-block with-errors"></div>
                        </div>
                   
                </div>        

</div>
                <!---728x90---> 
              <center>  <div class="form-group">
                    <input type="submit" id="submit" name="submit" value="submit" onclick="myFunction()" class="btn btn-info" style="width:30%";color:"white";background-color:blue;text-align: center;></button>
                </div></center>
            </form>
        </div> </div>
        <center><b><h4 style="color:white;">टिप:</h4></b></center>
        <center><b><h6 style="color:white;">हा कुठल्याही प्रकारचा सट्टा नसुन फक्त नागरिकांचे ओपीनियन घेण्यात येत आहे व अचुक ओपीनियन असणाऱ्यास बक्षीस  म्हणुन ठराविक रक्कम दिली जाईल.</h6></b></center>
        <div class="clear"></div>
    </div>
    <!---728x90--->  
    <!-- js -->
    <script src="{{url('/')}}/js/jquery-2.1.4.min.js"></script>
    <!-- //js -->

    <script src="{{url('/')}}/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/js/validator.min.js"></script>
    <!-- /js files -->
</body>




<script src="js/jquery-3.3.1.js"></script>
    <script src="js/bootstrap.js"></script>

    <script>
        $(document).ready(function(){
         
            $('#r1').hide();
            $('#r2').hide();
            $('#r3').hide();


            $('#n1').hide();
            $('#m1').hide();
            $('#p1').hide();
            $('#n11').hide();
            $('#m11').hide();
            $('#p11').hide();
         
        });
            
    
    function disableText()
    {
        var r11 = document.getElementById('r11');
      
        $('#r2').css('display','none');
        $('#r3').css('display','none');
        $('#r1').show();
    }

    function disableText1()
    {
        var r33 = document.getElementById('r22');
      
        $('#r1').css('display','none');
        $('#r3').css('display','none');
        $('#r2').show();
    }

    function disableText2()
    {
        var r33 = document.getElementById('r33');
      
        $('#r1').css('display','none');
        $('#r2').css('display','none');
        $('#r3').show();
    }



    </script>
         <script src="{{url('/')}}/aaa/js/jquery-3.3.1.js"></script>
        <script src="{{url('/')}}/aaa/js/bootstrap.js"></script>

        <script>
            $(document).ready(function(){
        $("#c1").hide();
        $("#c2").hide();
        $("#c3").hide();
        $("#c4").hide();
        $("#c5").hide();
        $("#c6").hide();
        $("#c7").hide();
        $("#c8").hide();
        $("#c9").hide();
        $("#c10").hide();

         $('#n').click(function(){
         var BJP = $("#n").val();
            if($(this).prop("checked") == true){
                $('#c1').show();
                $("#c1").val(BJP);
                //alert(level1);
            }
            else if($(this).prop("checked") == false){
               $('#c1').hide();
               $("#c1").value("");
            }
        });

         $('#m').click(function(){
           var Shivsena = $("#m").val();
            if($(this).prop("checked") == true){
               $("#c2").val(Shivsena);
                $('#c2').show();
            }
            else if($(this).prop("checked") == false){
               $('#c2').hide();
                $("#c2").value("");
            }
        });
  $('#p').click(function(){
           var level3 = $("#p").val();
            if($(this).prop("checked") == true){
               $("#c3").val(level3);
                $('#c3').show();
            }
            else if($(this).prop("checked") == false){
               $('#c3').hide();
                $("#c3").value("");
            }
        });


          $('#q').click(function(){
           var level4 = $("#q").val();
            if($(this).prop("checked") == true){
               $("#c4").val(level4);
                $('#c4').show();
            }
            else if($(this).prop("checked") == false){
               $('#c4').hide();
                $("#c4").value("");
            }
        });


          $('#r').click(function(){
           var level5 = $("#r").val();
            if($(this).prop("checked") == true){
               $("#c5").val(level5);
                $('#c5').show();
            }
            else if($(this).prop("checked") == false){
               $('#c5').hide();
                $("#c5").value("");
            }
        });

          $('#s').click(function(){
           var level6 = $("#s").val();
            if($(this).prop("checked") == true){
               $("#c6").val(level6);
                $('#c6').show();
            }
            else if($(this).prop("checked") == false){
               $('#c6').hide();
                $("#c6").value("");
            }
        });


          $('#t').click(function(){
           var level7 = $("#t").val();
            if($(this).prop("checked") == true){
               $("#c7").val(level7);
                $('#c7').show();
            }
            else if($(this).prop("checked") == false){
               $('#c7').hide();
                $("#c7").value("");
            }
        });

          $('#u').click(function(){
           var level8 = $("#u").val();
            if($(this).prop("checked") == true){
               $("#c8").val(level8);
                $('#c8').show();
            }
            else if($(this).prop("checked") == false){
               $('#c8').hide();
                $("#c8").value("");
            }
        });


          $('#v').click(function(){
           var level9 = $("#v").val();
            if($(this).prop("checked") == true){
               $("#c9").val(level9);
                $('#c9').show();
            }
            else if($(this).prop("checked") == false){
               $('#c9').hide();
                $("#c9").value("");
            }
        });


       

         $('#w').click(function(){
                   var level10 = $("#w").val();
                    if($(this).prop("checked") == true){
                       $("#c10").val(level10);
                        $('#c10').show();
                    }
                    else if($(this).prop("checked") == false){
                       $('#c10').hide();
                        $("#c10").value("");
                    }
                });




 });



        </script>

        
 <script type="text/javascript">
     //Near checkboxes
    $('.single-checkboxs').click(function() {
        $(this).siblings('input:checkbox').prop('checked', false);
    });
  </script>


<script type="text/javascript">

$('input[type=checkbox]').change(function(e){
   if ($('input[type=checkbox]:checked').length > 1) {
        $(this).prop('checked', false)
        alert("allowed only 1");
   }
})

</script>

  <script>
function ckChange(ckType){
    var ckName = document.getElementsByName(ckType.name);
    var checked = document.getElementById(ckType.id);

    if (checked.checked) {
      for(var i=0; i < ckName.length; i++){

          if(!ckName[i].checked){
              ckName[i].disabled = true;
          }else{
              ckName[i].disabled = false;
          }
      } 
    }
    else {
      for(var i=0; i < ckName.length; i++){
        ckName[i].disabled = false;
      } 
    }    
}
</script>
 <script>
$(document).ready(function(){
    $('.chs').click(function() {
        $('.chs').not(this).prop('checked', false);
    });
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript">
$('#numberbox').keyup(function(){
  if ($(this).val() > 1000){
    alert("amound should be equal to or less than 1000");
    $(this).val('1000');
  }
})
</script>
<!-- Mirrored from demo.w3layouts.com/demos_new/template_demo/13-12-2017/student_registration_form-demo_Free/1974889183/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Jun 2019 10:18:13 GMT -->
</html>