  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('/')); ?>/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <?php
            $user = Sentinel::check();
          ?>
          <p><?php echo e(isset($user->user_name) ? $user->user_name : 'User'); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="">
          <a href="<?php echo e(url('/')); ?>/admin/dashboard">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <?php /* <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span> */ ?>
          </a>
        </li>
        <?php 
        if($user->is_admin=='1'){?>
         <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-user"></i>Admin <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/change_password" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Change Password</a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-users"></i>Users <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/user_list" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Users List</a>
            </li>
          </ul>
        </li>
        <li class="bold"><a href="<?php echo e(url('/')); ?>/admin/link_send" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Send Link</a>
        </li>
        <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-image"></i>Geneology <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/work_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Accept Payment</a>
            </li>
            <li>
               <a href="<?php echo e(url('/')); ?>/admin/level_tree?id=<?php echo e($user->email); ?>" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Level Tree</a>
            </li>
            <li>
               <a href="<?php echo e(url('/')); ?>/admin/transaction" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Transaction</a>
            </li>
          </ul>
        </li>
        <li>
         <a href="<?php echo e(url('/')); ?>/admin/support" class="waves-effect waves-cyan"><i class="fa fa-angellist"></i> Support</a>
        </li>
        <?php }else{ ?>
        <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-user"></i>User <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/profile_edit" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Change Profile</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/bank_edit" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Change Bank Details</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/change_password" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Change Password</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/change_trans_password" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Change Transaction Pin</a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-image"></i>Geneology <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/self_team" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Teamview</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/level_tree?id=<?php echo e($user->email); ?>" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Level Tree</a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a class="collapsible-header waves-effect waves-cyan"><i class="fa fa-credit-card"></i>Wallet <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/u_daily_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Daily Growth</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/u_work_income" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i> Accept Income</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/user_transaction" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Transction-Receive</a>
            </li>
            <li>
              <a href="<?php echo e(url('/')); ?>/admin/user_transaction_" class="waves-effect waves-cyan"><i class="fa fa-circle-o"></i>Transction-Send</a>
            </li>
          </ul>
        </li>
        <li class="bold"><a href="<?php echo e(url('/')); ?>/admin/u_support" class="waves-effect waves-cyan"><i class="fa fa-angellist"></i> Support</a>

        <?php }?>
        <li class="bold"><a href="<?php echo e(url('/')); ?>/admin/logout" class="waves-effect waves-cyan"><i class="fa fa-close"></i> Logout</a>
        </li>

      </ul>
    </section>
    <!-- /.sidebar -->

  </aside>