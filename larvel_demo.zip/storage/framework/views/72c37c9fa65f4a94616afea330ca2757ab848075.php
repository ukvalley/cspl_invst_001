                

<?php $__env->startSection('main_content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Support
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Support</li>
      </ol>
    </section>

   
                
              <?php 
$user = Sentinel::check();

    $data_plan = \DB::table('plans')->where('plan_amount','=',$user->plan)->first();
    ?>
                
                
                 <?php
                 $user = Sentinel::check();
                 $tran_data = \DB::table('transaction')->join('users', 'transaction.level_id', '=', 'users.email')->where(['reciver_id'=>$user->email])->where(['transaction.generator'=>'system'])->where('transaction.activity_reason','=','level')->select('transaction.level_id as sender_id','transaction.reciver_id','transaction.id as trans_id','users.id as user_sender_id','users.is_active','transaction.date','transaction.approval','transaction.generator','transaction.amount')->get();
                 
                 $amount=0;
                 ?>
                 
                 <?php foreach($tran_data as $key=>$value): ?>
                 
                <?php 
                 if($value->is_active==2)
                 {
                 $amount+=$value->amount; 
                }
                 ?>
                 <?php endforeach; ?>
                 
                 
                  <?php $day = $data_plan->no_of_days; $amount_daily =0; $counter = 0; ?>
                <?php for($i =1; $i <= $data_plan->no_of_days; $i++): ?>
                <?php 
                  

                  $counter++;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                  /*if(date('l', strtotime($date))=='Saturday' || date('l', strtotime($date))=='Sunday')
                  {
                    $i--;
                    continue;
                    //$amount = $amount-400;
                  }*/
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day-1;
                      $amount_daily = $amount_daily+$data_plan->daily;
                      
                  }
                  
                ?>
                <?php endfor; ?>
                
                
                  <?php
                 $user = Sentinel::check();
                 $tran_data = \DB::table('transaction')->where(['reciver_id'=>$user->email])->where(['generator'=>'reciever'])->where('activity_reason','=','level_withdrawl')->get();
                 
                 $amount_withdraw=0;
                 ?>
                 
                 <?php foreach($tran_data as $key=>$value): ?>
                 
                <?php $amount_withdraw+=$value->amount; ?>
                 
                 <?php endforeach; ?>
                 
                 <?php  $wallet_balance= $amount-$amount_withdraw ?>
            
               <section class="content">
      <div class="row">
        <div class="col-md-12">
           <div class="box box-info">
            <div class="box-header">
              <i class="fa fa-envelope"></i>

              <h3 class="box-title">Withdrawl</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
               <?php /*  <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fa fa-times"></i></button> */ ?>
              </div>
            
            
          
            
              <!-- /. tools -->
              <form id="form" action="<?php echo e(url('/')); ?>/admin/withdrawal_payment" class="col s12" method="get" onsubmit="return validateForm()" <?php /* data-parsley-validate="" */ ?>>
                 <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo e(csrf_field()); ?>

              
               <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
             <span id="error_total_amount" style="float: center; color:red" </span>
               </div>
                </div>
              </div>
              
              <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Wallet Balance</label> <br>
                     <input disabled id="wallet_amt" name="wallet_amt" type="text" class="form-control" placeholder="Title" required="true" value="<?php echo e($wallet_balance); ?>">
                  </div>
                </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Withdrawl Amount</label> <br>
                    <select id="withdrawl_amt" name="withdrawl_amt" class="form-control"required="true">
                         <option value="1000">1000</option>
                              <option value="2000">2000</option>
                                </select>
                  </div>
                </div>
              </div>
              
              <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                  </div>
                </div>
              </div>
              </form>
            </div>
        </div>   
        </div>
       
       
       
       
       
       
        <!-- /.col -->
        
        
        
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
   
  </div>
  <!-- /.content-wrapper -->
  
  
  <script src="http://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>

<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>
  
  <script type="text/javascript">
    $(document).ready(function()
    {
      $("#form").submit(function()
      {
        var wallet_amt = $('#wallet_amt').val();
        var withdrawl_amt      = $('#withdrawl_amt').val();
       
        
        if(parseInt(withdrawl_amt)<'1000')
        {
          $('#error_total_amount').text('Withdrawl Amount Should be greater than min 1000 and max 2000 Rs');
          
          return false;
        }
        else if(parseInt(wallet_amt)<parseInt(withdrawl_amt))
        { 
          $('#error_total_amount').text('Amount should not grater than total amount');
          return false;
        }
        
        
        else if(parseInt(withdrawl_amt)>'2000')
        { 
          $('#error_total_amount').text('Daily Withdrawl Limit is Max 2000 and min 1000');
          return false;
        }
        else 
        {
          $('#error_total_amount').text('');
        }
      });
    });
  </script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>