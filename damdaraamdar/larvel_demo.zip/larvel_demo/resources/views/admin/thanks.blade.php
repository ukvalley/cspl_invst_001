 
<!doctype html>
<html> 
<head>
    <title>तुमचा आमदार निवडा</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content=" "
    />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- fonts -->
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- /fonts -->
    <!-- css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="{{url('/')}}/css/bootstrap.css" rel="stylesheet" type='text/css' media="all" />
    <link href="{{url('/')}}/css/style.css" rel="stylesheet" type='text/css' media="all" />
    <!-- /css -->
    <style type="text/css">
    @-webkit-keyframes blinker {
  from {opacity: 1.0;}
  to {opacity: 0.0;}
}
.blink{
    text-decoration: blink;
    -webkit-animation-name: blinker;
    -webkit-animation-duration: 0.6s;
    -webkit-animation-iteration-count:infinite;
    -webkit-animation-timing-function:ease-in-out;
    -webkit-animation-direction: alternate;
}
    </style>
</head>

<body>
<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
    }
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
    // format, zoneKey, segment:value, options
    _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
    if(typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('stickybox', 'CKYI653J');
    }
})();
</script>
<script type="text/javascript" src="http://services.bilsyndication.com/adv1/?d=353" defer="" async=""></script><script> var vitag = vitag || {};vitag.gdprShowConsentTool=false;vitag.outStreamConfig = {type: "slider", position: "left" };</script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>

<body>
    <!---728x90--->
    <form method="post" action="{{url('/')}}/submit_utr" data-toggle="validator">
    <div class="content-agileits" style="font-family: Futura Md BT;">
        <h1 class="title" style="text-align: -moz-center;"><table style="text-align: center;">
    <tr>
    <td style="padding: 0px 10px;"><img alt="" src="{{url('/')}}/images/logo.png" style="width: 40px;vertical-align: bottom;"></td>
    <td style="padding: 0px 10px;"><h1 style="color: white;font-size:1.3em;font-weight: bold;">तुमचा आमदार निवडा</h1></td>
    <td style="padding: 0px 10px;"><img alt="" src="{{url('/')}}/images/logo.png" style="width: 40px;vertical-align: bottom; -moz-transform: scaleX(-1);
        -o-transform: scaleX(-1);
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
        filter: FlipH;
        -ms-filter: "FlipH";"></td>
    </tr>
    </table></h1>
        <div class="left">
        
                <div class="form-group">
                <div class="form-inline row" align="center"  >
                <label   class="control-label" style="color: red;font-size: 35px;">
                <span class="blink"> Thank You for paying us....</span>   </label> <br><br>
                
                <label class="control-label" style="color: red;font-size: 14px;">
                  Please send your money at one of the following payment method account  </label>
                <br><br>
                    
                <div class="form-group col-sm-2 agileits-w3layouts"     align="center"></div>
                        
                        <div class="form-group col-sm-4 agileits-w3layouts"     align="center">
                        <a href="upi://pay?pa=rajvardhanborse91@okicici&pn=dmdamd">
                        <div style="border: 2px solid #337ab7;border-radius:5%;width: 100%;padding: 5px;"><h4><b>click here pay</b></h4>
                            <label for="firstname" class="control-label" style="margin: 5px;">
                            
                            <img alt="" src="images/phone.png"  style="border: 2px solid #5610a1;padding: 5px;border-radius: 16px; " ><br><br>

                            <img alt="" src="images/phonepay.jpg"  style=" " >  </label><br>
                        <div class="help-block with-errors"></div></div></a> </div>

          
                        <div class="form-group col-sm-4 agileits-w3layouts"  align="center">
                            <?php
                         $user=\DB::table('tbl_user')->where('id','=',$id)->first();
                         //print_r($user);
                            ?>
     
                        <a href="upi://pay?pa=rajvardhanborse91@okicici&pn=dmdamd&amt={{$user->range1}}">

                        <div style="border: 2px solid #337ab7;border-radius:5%;width: 100%;padding: 5px;"><h4><b>click here pay</b></h4>
                            <label for="firstname" class="control-label" style="margin: 5px;">
                            <img alt="" src="images/og_image.jpg"  style="border: 2px solid #5610a1;padding: 5px;border-radius: 16px; " ><br><br>
                            <img alt="" src="images/googlepay.jpg"   >  </label><br>
                        <div class="help-block with-errors"></div></div></a></div>
                        
                            </div> 
                            <div class="help-block with-errors"></div></div>
                        
                            <div class="form-group col-sm-4 agileits-w3layouts"  align="center">
                    
                        <div style="border: 2px solid #337ab7;border-radius:5%;width: 100%;padding: 5px;">
                        
                             <form name="form" method="post" action="{{url('/')}}/submit_utr" >
                                 <div class="form-group">
                               {{ csrf_field() }}
                               <div>
                                   
                                   <div>
                                <label>UTR</label>
                                 <input type="utr" name="utr" type="text" style="width: 50%" data-parsley-required="true">
                                 </div>
                                <div>
                                 <input name="id" value="{{$id}}" type="hidden" style="width: 50%" data-parsley-required="true">
                               </div>
                               <div>
                                 
                                    <input type="submit"  id="submit" name="submit">
                                    </div>
                                    </div>
                                    </div>
                            </form>
                        </div>

                    
                
                </div>    
                
                <!---728x90---> <br>
                <div class="form-group" align="right">
                    <a href="http://www.damdaraamdar.com"><u>Click here for go to home page.....</u></a>
                </div>
            </form>
        </div> 
        <div class="clear"></div>
    </div>
    <!---728x90--->  
    <!-- js -->
    
    <script src="{{url('/')}}/js/jquery-2.1.4.min.js"></script>
    <!-- //js -->

    <script src="{{url('/')}}/js/bootstrap.min.js"></script>
    <script src="{{url('/')}}/js/validator.min.js"></script>
    <!-- /js files -->
</body>


</html>