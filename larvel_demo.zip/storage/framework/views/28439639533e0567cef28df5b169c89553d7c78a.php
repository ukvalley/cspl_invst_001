                

<?php $__env->startSection('main_content'); ?>

<?php
$data_setting = \DB::table('site_setting')->where('id','=','1')->first();

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Send Payment
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Send Payment to <?php echo e($data->user_name); ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
           <div class="box box-info">
            <div class="box-header">
              <i class="fa fa-money"></i>

              <h3 class="box-title">Send to-<?php echo e($data->user_name); ?></h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
               <?php /*  <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fa fa-times"></i></button> */ ?>
              </div>
              <!-- /. tools -->
              <form class="col s12" method="post" action="<?php echo e(url('/')); ?>/admin/process_change_pass" data-parsley-validate="">
              <?php echo e(csrf_field()); ?>

               <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>Username</label>:</td>
                        <td><?php echo e($data->user_name); ?></td>
                      </tr>
                    </table>
                  
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>User Id:</td>
                        <td><?php echo e($data->email); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>Sponcer Id:</td>
                        <td><?php echo e($data->spencer_id); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>Mobile No.:</td>
                        <td><?php echo e($data->mobile); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
              <!--  <div class="col-md-6">


<div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>Bank:</td>
                        <td><?php echo e($data->banck_name); ?></td>
                      </tr>
                    </table>
                  </div>


                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>BRANCH :</td>
                        <td><?php echo e($data->branch); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>IFSC:</td>
                        <td><?php echo e($data->ifsc); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>BANK ACCOUNT NO. :</td>
                        <td><?php echo e($data->bank_account_no); ?></td>
                      </tr>
                    </table>
                  </div>  
                </div>-->
            <!--    <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>PAYTM :</td>
<?php if($data->paytm!=null && strlen($data->paytm) >= 10): ?>
                       <td> <a href="paytmmp://cash_wallet?featuretype=sendmoneymobile&recipient=<?php echo e($data->paytm); ?>&amount=10" ><button type="button" class="btn bg-navy btn-flat margin"><?php echo e($data->paytm); ?><br> click here or pay on paytm</button></td></a>
<?php else: ?>
<td>Not Available</td>
<?php endif; ?>

                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>PHONEPE :</td>
<?php if($data->phonepe!=null && strlen($data->phonepe) >= 10): ?>
                        <td><a href="upi://pay?pa=<?php echo e($data->phonepe); ?>@ybl&pn=<?php echo e($data->user_name); ?>&am=1"><button type="button" class="btn bg-purple btn-flat margin"><?php echo e($data->phonepe); ?><br> click here or pay on phonepe</button></td></a>
<?php else: ?>
<td>Not Available</td>
<?php endif; ?>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>TEZ :</td>
<?php if($data->tez!=null && strlen($data->tez) >= 10): ?>
                        <td><?php echo e($data->tez); ?></td>
<?php else: ?>
<td>Not Available</td>
<?php endif; ?>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>BHIM_UPI :</td>
<?php if($data->bhim_upi!=null && strlen($data->bhim_upi) >= 3): ?>
                        <td><a href="upi://pay?pa=<?php echo e($data->bhim_upi); ?>&pn=<?php echo e($data->user_name); ?>&am=10&aid=uGICAgIDV5bKjXg"><button type="button" class="btn bg-orange btn-flat margin"><?php echo e($data->bhim_upi); ?><br> click here or pay on Bhim UPI</button></a></td>
<?php else: ?>
<td>Not Available</td>
<?php endif; ?>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <table>
                      <tr>
                        <td width="150"><label>Amount :</td>
                        <td>10</td>
                      </tr>
                    </table>
                  </div>
                </div>-->

<div class="col-md-6">
                  <div class="form-group">
<a href="https://api.whatsapp.com/send?phone=91<?php echo e($data->mobile); ?>&text=Hello I am <?php echo e(Sentinel::getUser()->user_name); ?> My ID <?php echo e(Sentinel::getUser()->email); ?> from <?php echo e($data_setting->site_name); ?>. I have recieve payment link of from you( User id-> <?php echo e($data->email); ?> and User name-> <?php echo e($data->user_name); ?>). Please send payment so I can accept your payment. Yours faithfully <?php echo e(Sentinel::getUser()->user_name); ?> Member of <?php echo e($data_setting->site_name); ?>" class="btn btn-block btn-social btn-facebook">
                <i class="fa fa-whatsapp"></i> Send confirmation message to Sender on whatsapp
              </a>

                    
                  </div>
                </div>



              </div>
              <?php /* <div class="row" style="margin-top: 20px">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="submit" class="btn cyan waves-effect waves-light right" id="submit" name="submit">
                  </div>
                </div>
              </div> */ ?>
              </form>
            </div>
        </div>   
        </div>
       
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
   
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>