<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use URL;
use Mail;
use Session;
use Sentinel;
use Validator;
use App\Models\UserModel;
use App\Models\CitiesModel;
use App\Models\StatesModel;
use App\Models\CountriesModel;
use App\Models\TransactionModel;
use App\Models\EmailTemplateModel;

class AdminController extends Controller
{
    public $arr_view_data;
    public $admin_panel_slug;

    public function __construct(UserModel $user_model)
    {
      $this->UserModel          = $user_model;
      $this->arr_view_data      = [];
      $this->admin_panel_slug   = config('app.project.admin_panel_slug');
    }

  
   //call view
   public function profile_creator_new()
   {
    return view('admin.create_profile_creator',$this->arr_view_data);

   }

   //process form data
  public function new_profile_creator(Request $request)
    {
     //print_r('dfsdfdsf');exit;

     //  print_r($request->input('p1'));

      $validator = Validator::make($request->all(), [
 
       ]);

     if ($validator->fails()) 
      {
         return redirect('/profile_creator_new')
                     ->withErrors($validator)
                       ->withInput($request->all());
     }

       $user  = Sentinel::check();
       $arr_support                      = [];

      
     
      //  $arr_support['p1111']              = $request->input('p1');
        $arr_support['name']              = $request->input('name');
        $arr_support['contect_no']        = $request->input('contect_no');

         $arr_support['paymentmode']        = $request->input('paymentmode');
       $arr_support['paymentamt'] =        implode('', (array) $request->get('p1'));

       $arr_support['district']          = $request->input('district');
       $arr_support['taluka']            = $request->input('taluka');
       $arr_support['village']           = $request->input('village');
       $arr_support['chklist'] = implode(',', (array) $request->get('chklist'));
        $arr_support['investing']         = $request->input('investing');
       $arr_support['investing_amount']  = $request->input('investing_amount');

       \DB::table('tbl_user')->insert($arr_support);
       echo "success";
    print_r($user);exit;
      //return redirect()->back()->with('success');

    }

  
   

}

  




