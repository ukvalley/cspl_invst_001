
Hello {{$data['name']}}.
{{$data['message']}}