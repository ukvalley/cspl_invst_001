<!-- HEader -->        
<?php echo $__env->make('admin.layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
        
<!-- BEGIN Sidebar -->
<?php echo $__env->make('admin.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END Sidebar -->

<!-- BEGIN Content -->

    <?php echo $__env->yieldContent('main_content'); ?>

    <!-- END Main Content -->

<!-- Footer -->        
<?php echo $__env->make('admin.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
                
              