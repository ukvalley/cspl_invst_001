<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use URL;
use Mail;
use Session;
use Sentinel;
use Validator;
use App\Models\UserModel;
use App\Models\CitiesModel;
use App\Models\StatesModel;
use App\Models\CountriesModel;
use App\Models\TransactionModel;
use App\Models\EmailTemplateModel;


class AdminController extends Controller
{
    public $arr_view_data;
    public $admin_panel_slug;

    public function __construct(UserModel $user_model)
    {
      $this->UserModel          = $user_model;
      $this->arr_view_data      = [];
      $this->admin_panel_slug   = config('app.project.admin_panel_slug');
    }

  
   //call view
   public function profile_creator_new()
   {
    return view('admin.create_profile_creator',$this->arr_view_data);

   }

   //process form data
  public function new_profile_creator(Request $request)
    {
     //print_r('dfsdfdsf');exit;

     //  print_r($request->input('p1'));

      $validator = Validator::make($request->all(), [
 
       ]);

     if ($validator->fails()) 
      {
         return redirect('/profile_creator_new')
                     ->withErrors($validator)
                       ->withInput($request->all());
     }

       $user  = Sentinel::check();
       $arr_support                      = [];

      
     
      //  $arr_support['p1111']              = $request->input('p1');
        $arr_support['name']              = $request->input('name');
        $arr_support['contect_no']        = $request->input('contect_no');
         $arr_support['refno']        = $request->input('refno');
         $arr_support['paymentmode']        = $request->input('paymentmode');
       $arr_support['paymentamt'] =        implode('', (array) $request->get('p1'));
        $arr_support['state']          = $request->input('state');
       $arr_support['district']          = $request->input('district');
       $arr_support['taluka']            = $request->input('taluka');
       $arr_support['village']           = $request->input('village');
       $arr_support['chklist'] = implode(',', (array) $request->get('chklist'));
       $arr_support['range1'] =  $request->input('range');
      
     // print_r($arr_support);exit; 

      $status= \DB::table('tbl_user')->insertGetId($arr_support);
      
    //  $status = DB::getPdo()->lastInsertId();;
   
        return redirect()->route('thanks')->with( [ 'id' => $status ] );
   

    }

  public function thanks()
   {
    //print_r('dfsdf');exit;
    $id = session()->get( 'id' );
    //print_r($id);
    $this->arr_view_data['id'] = $id;

    return view('admin.thanks',$this->arr_view_data);
   }
   
     public function submitss()
   {
    return view('admin.thanks',$this->arr_view_data);

   }

    public function submit_utr(Request $request)
   {
   
//print_r('dfsf');exit;
     //  print_r($request->input('p1'));

      $validator = Validator::make($request->all(), [
 
       ]);

     if ($validator->fails()) 
      {
         return redirect('/submitss')
                     ->withErrors($validator)
                       ->withInput($request->all());
     }

       
       $arr_support                      = [];

     
       $arr_support['utr']              = $request->input('utr');
         $arr_support['id']              = $request->input('id');
        
       

      $status=\DB::table('tbl_user')->where('id','=',$request->input('id'))->update($arr_support);
      
       return redirect()->route('profile_creator_new');
      
   }
   
   public function views()
   {
       $customer_data = \DB::table('tbl_user')->get();
     return view('admin.views')->with('customer_data', $customer_data);
   }

   

}

  




