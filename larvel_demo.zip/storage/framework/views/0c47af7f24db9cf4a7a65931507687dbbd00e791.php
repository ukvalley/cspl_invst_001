                

<?php $__env->startSection('main_content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Level Income
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Level Income</li>
      </ol>
    </section>

     <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Level Income</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto;">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Sender Id</th>    
                  <th>Reciver Id</th>    
                  <th>Date</th>
                  <th>Amount</th>
                 <?php /*  <th>Receipt</th> */ ?>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                  <?php foreach($data as $key=>$value): ?>
                   <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e(isset($value->sender_id) ? $value->sender_id : 'NA'); ?></td>   
                    <td><?php echo e(isset($value->reciver_id) ? $value->reciver_id : 'NA'); ?></td>   
                    <td><?php echo e(isset($value->date) ? $value->date : 'NA'); ?></td>
                    <td><?php echo e($value->amount); ?></td>
                 <?php /*    <td>
                      <?php if(!empty($value->receipt_file)): ?>
                        <a href="" download=""><i class="fa fa-download"></i></a>
                      <?php else: ?>
                        NA
                      <?php endif; ?>
                    </td> */ ?>
                    <td>
                      <?php if($value->approval=='completed'): ?>
                        <a href="javascript:void(0)" class="btn label-success">Payment Received</a>
                      <?php elseif($value->approval=='payment_done'): ?>
                       
                         <?php if($value->is_active==0 && $value->generator!='system'): ?>   
                        <a onclick="open_model(this)" data-sample-id="<?php echo e($value->trans_id); ?>" value="<?php echo e($value->trans_id); ?>" href="<?php echo e(url('/')); ?>/admin/reclaim_payment?id=<?php echo e($value->trans_id); ?>" class="button1 btn label-warning">Reclaim Payment</a>
                        <?php else: ?>
                          <a onclick="open_model(this)" data-sample-id="<?php echo e($value->trans_id); ?>" value="<?php echo e($value->trans_id); ?>"  href="<?php echo e(url('/')); ?>/admin/accept_payment?id=<?php echo e($value->trans_id); ?>"  class="button1 btn label-danger">Accept Payment</a>
                      
                       <?php endif; ?>
                       
                      <?php else: ?>
                        <button class="btn label-info">Payment Inprocess</button>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
   
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>