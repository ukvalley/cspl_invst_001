                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Deposite Account</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Deposite Account</a>
                        </li>
                      </ol>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              <div class="row">
                <div class="col s12 m12 12">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Id</th>
                            <th>Bank Name</th>
                            <th>A/C Holder</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                 
                    <tbody>
                        <?php foreach($data as $key=>$user): ?>
                          <tr>
                              <td><?php echo e($key+1); ?></td>
                              <td><?php echo e($user['email']); ?></td>
                              <td><?php echo e(base64_decode(base64_decode($user['bank_name']))); ?></td>
                              <td><?php echo e(base64_decode(base64_decode($user['bank_holder_name']))); ?></td>
                              <td>
                                <?php
                                  if($user['bank_active']=="0")
                                  {
                                ?>
                                   <a href="<?php echo e(url('/').'/admin/change_deposite_account/'.base64_encode($user['id'])); ?>" style="color: red">Block</a>
                                <?php }else{ ?>
                                  <a href="<?php echo e(url('/').'/admin/change_deposite_account/'.base64_encode($user['id'])); ?>" style="color: green">Unblock</a>
                                <?php }?>
                                
                              </td>
                          </tr>
                        <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>