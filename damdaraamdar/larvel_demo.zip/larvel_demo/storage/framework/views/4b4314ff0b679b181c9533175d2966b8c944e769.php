<html>
<head>
<title>Level Tree</title>

<!-- tree -->
<style type="text/css">
ul.tree {
  overflow-x: auto;
  white-space: nowrap;  
}
ul.tree,
ul.tree ul {
  width: auto;
  margin: 0;
  padding: 0;
  list-style-type: none;
}
ul.tree li {
  display: block;
  width: auto;
  float: left;
  vertical-align: top;
  padding: 0;
  margin: 0;
}
ul.tree ul li {
  background-image: url(data:image/gif;base64,R0lGODdhAQABAIABAAAAAP///ywAAAAAAQABAAACAkQBADs=);
  background-repeat: repeat-x;
  background-position: left top;
}
ul.tree li span {
  display: block;
  width: 5em;
  /*
    uncomment to fix levels
    height: 1.5em;
  */
  margin: 0 auto;
  text-align: center;
  white-space: normal;
  letter-spacing: normal;
}
</style>
<!--[if IE gt 8]> IE 9+ and not IE -->
<style type="text/css">
ul.tree ul li:last-child {
  background-repeat: no-repeat;
  background-size:50% 1px;
  background-position: left top;
}
ul.tree ul li:first-child {
  background-repeat: no-repeat;
  background-size: 50% 1px;
  background-position: right top;
}
ul.tree ul li:first-child:last-child {
  background: none;
}
ul.tree ul li span {
  background: url(data:image/gif;base64,R0lGODdhAQABAIABAAAAAP///ywAAAAAAQABAAACAkQBADs=) no-repeat 50% top;
  background-size: 1px 0.8em;
  padding-top: 1.2em;
}
ul.tree ul {
  background: url(data:image/gif;base64,R0lGODdhAQABAIABAAAAAP///ywAAAAAAQABAAACAkQBADs=) no-repeat 50% top;
  background-size: 1px 0.8em;
  margin-top: 0.2ex;
  padding-top: 0.8em;
}
</style>
<style type="text/css">
body {
  font-family:sans-serif;
  color: #666;
  text-align: center;
}
A, A:visited, A:active {
  color: #c00;
  text-decoration: none;
}
A:hover {
  text-decoration: underline;
}
ul.tree,
#wrapper {
  width: 1600px;
  margin: 0 auto;
}
ul.tree {
  width: 1600px;
}
.clearer {
  clear: both;
}
p {
  margin-top: 2em;
}
</style>
</head>

 <div style="background-color: #3c8dbc;height: 7%;width:1600px"></div>
<body style="background-color: #ecf0f5;">
   
<div id="wrapper" >
    <br>
    <br>
    <br>
<ul class="tree">
  <li>
    <span><img src="<?php echo e(url('/')); ?>/images/user_tree.png" style="height: 60px;"><br><?php echo e(isset($root_user) ? $root_user : 'NA'); ?></span>
    <ul>
      <?php for($j=0;$j<4;$j++): ?>
      <li>
        <span><?php if(isset($data[$j]['email'])): ?><a href="<?php echo e(url('/')); ?>/admin/level_tree?id=<?php echo e(isset($data[$j]['email']) ? $data[$j]['email'] : 'NA'); ?>" ><img src="<?php echo e(url('/')); ?>/images/user_tree.png" style="height: 60px;<?php if($data[$j]['is_active']==0): ?> background-color: red; <?php elseif($data[$j]['join_count']>=10): ?> background-color:green; <?php elseif($data[$j]['join_count']<10): ?> background-color: yellow; <?php endif; ?>"></a><?php else: ?>  <img src="<?php echo e(url('/')); ?>/images/user_tree.png" style="height: 60px;"></i><?php endif; ?> <br><?php echo e(isset($data[$j]['email']) ? $data[$j]['email'] : 'NA'); ?></span>
        <ul>
          <?php for($i=0;$i<4;$i++): ?>
          <?php
            $user_id = (isset($data[$j]['email']))? $data[$j]['email']:'NA';
            $result = \DB::table('users')->where(['spencer_id'=>$user_id])->get();

          ?>
          <li class="origin">
            <span><?php if(isset($result[$i]->email)): ?><a href="<?php echo e(url('/')); ?>/admin/level_tree?id=<?php echo e(isset($result[$i]->email) ? $result[$i]->email : 'NA'); ?>"><img src="<?php echo e(url('/')); ?>/images/user_tree.png" style="height: 60px;<?php if($result[$i]->is_active==0): ?> background-color: red; <?php elseif($result[$i]->join_count>=10): ?> background-color: green; <?php elseif($result[$i]->join_count<10): ?> background-color: yellow; <?php endif; ?>"></a><?php else: ?>  <img src="<?php echo e(url('/')); ?>/images/user_tree.png" style="height: 60px;"></i><?php endif; ?> <br><?php echo e(isset($result[$i]->email) ? $result[$i]->email : 'NA'); ?></span>
          </li>
          <?php endfor; ?>
        </ul>
      </li>
      <?php endfor; ?>
  </li>
</ul>
<div class="clearer"></div>

<br>
<br>
<br>
<a  href="<?php echo e(url('/')); ?>/admin/dashboard">Back to Dashboard</a>
</div>
<div style="">
  <table border="1">
    <tr>
      <td colspan="2"><b>User Details</b></td>
    </tr>
    <tr>
      <td>User name</td>
      <td><?php echo e(isset($user->user_name) ? $user->user_name : 'NA'); ?></td>
    </tr>
    <tr>
      <td>User Id</td>
      <td><?php echo e(isset($user->email) ? $user->email : 'NA'); ?></td>
    </tr>
    <tr>
      <td>Mobile</td>
      <td><?php echo e(isset($user->mobile) ? $user->mobile : 'NA'); ?></td>
    </tr>
    <tr>
      <td>Sponcer id</td>
      <td><?php echo e(isset($user->spencer_id) ? $user->spencer_id : 'NA'); ?></td>
    </tr>
  </table>
</div>
</body>
</html>