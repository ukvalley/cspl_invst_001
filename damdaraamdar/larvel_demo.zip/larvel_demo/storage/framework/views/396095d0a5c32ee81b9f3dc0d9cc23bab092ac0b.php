                

<?php $__env->startSection('main_content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content light-blue">

<?php
 $data_news = \DB::table('newsfeed')->where('id','=','1')->first();
 $user = Sentinel::check();
?>
<?php if($user->epin!=''): ?>
<marquee class="bg-orange" style="padding: 1%;"><?php echo e($data_news->news_feed); ?></marquee>
<?php else: ?>
<marquee class="bg-orange" style="padding: 1%;">Please Activate Your Epin</marquee>
<?php endif; ?>
<!-- <div class="form-group bg-orange">
<a href="https://chat.whatsapp.com/LTtmeUo4GpW4GONLbYyNj2" class="btn btn-block btn-social btn-facebook bg-orange">
                <i class="fa fa-whatsapp"></i>Click to Join Whatsapp Group
              </a>

                    
                  </div> -->

  <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">User Details</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body bg-white" style="background-color: #FFFFFF;color: black">
                  <div class="col-md-12" >
                    <div class="row">
                      <script>
                                  // Set the date we're counting down to
                                  //var countDownDate = new Date("April 17, 2018 11:39:25").getTime();
                                  <?php if($user->recommitment_at!="0000-00-00 00:00:00"): ?>
                                   //alert('<?php echo(date("M d, Y H:i:s",  strtotime("+"."1 days", strtotime($user->recommitment_at)))); ?>');
                                  var countDownDate = new Date('<?php echo(date("M d, Y H:i:s",  strtotime("+"."48 hours", strtotime($user->recommitment_at)))); ?>').getTime();
                                  
<?php else: ?>
                                  //alert('<?php echo(date("M d, Y H:i:s",  strtotime("+"."48 hours", strtotime($user->created_at)))); ?>');
                                  var countDownDate = new Date('<?php echo(date("M d, Y H:i:s",  strtotime("+"."48 hours", strtotime($user->created_at)))); ?>').getTime();
                                  <?php endif; ?>

                                  // Update the count down every 1 second
                                  var x = setInterval(function() {

                                      // Get todays date and time
                                      var now = new Date().getTime();
                                      
                                      // Find the distance between now an the count down date
                                      var distance = countDownDate - now;
                                      
                                      // Time calculations for days, hours, minutes and seconds
                                      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                      var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                                      
                                      // Output the result in an element with id="demo"
                                      document.getElementById("demo").innerHTML =  days + "D " + hours + "H "
                                      + minutes + "M " + seconds + "S ";
                                      
                                      // If the count down is over, write some text 
                                      if (distance < 0) {
                                          clearInterval(x);
                                          document.getElementById("demo").innerHTML = "Commitment Done";
                                         // $('#div_link').remove();
                                      }
                                  }, 1000);
                                </script>
<?php if($user->is_active==1): ?>
                      <div class="col-md-12">Expiration Remain:<span class="task-card-date" style="color: red;font-size: 20px" id="demo"></span></div>
                      
<?php endif; ?>
                      <div class="col-md-6">User Name:  <?php echo e(isset($user->user_name) ? $user->user_name : 'NA'); ?></div>
                       <div class="col-md-6">Transaction Pin: <?php echo e(isset($user->transaction_pin) ? $user->transaction_pin : 'NA'); ?></div>
                      <div class="col-md-6">User Id: <?php echo e(isset($user->email) ? $user->email : 'NA'); ?></div>
                      <div class="col-md-6">Created Date: <?php echo e(isset($user->created_at) ? $user->created_at : 'NA'); ?></div>
                    </div>
                   
                 
                </div>
                
                <div class="callout callout-info">
                Referal Link:<input class="form-control input-sm" value="<?php echo e(url('/')); ?>/admin/registration?sponcer_id=<?php echo e($user->email); ?>" type="text" placeholder="Type a comment" autocomplete="off">
              </div>
</div>
</div>

      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              
<?php 
$user = Sentinel::check();

    $data_plan = \DB::table('plans')->where('plan_amount','=',$user->plan)->first();
    ?>
                <?php $day = $data_plan->no_of_days; $amount =0; $counter = 0; ?>
                <?php for($i =1; $i <= 30; $i++): ?>
                <?php 
                  

                  $counter++;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                 
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day+1;
                  }
                  
                ?>
                <?php endfor; ?>
                
                <?php $amt =  $data_plan->plan_amount-($data_plan->daily*($data_plan->no_of_days-$day)) ?>
                <?php if($user->is_active==2): ?>
                    <h3><?php echo e($data_plan->plan_amount); ?></h3>

                   
                    <?php if($day>=10): ?>
                    <a href="<?php echo e(url('/')); ?>/admin/recommit?email=<?php echo e($user->email); ?>" class="btn bg-olive"></a>
                    <?php else: ?>
                     <p>Commitment</p>
                    <?php endif; ?>
                <?php elseif($user->is_active==0): ?>
                     <h3>Block</h3>
                  <?php else: ?>
                      <h3>Inactive</h3>
                      <p>Commitment</p>
                <?php endif; ?>
              
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer"> <?php echo e($day-3); ?> Days<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->



 
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              
<?php 
$user = Sentinel::check();

    $data_plan = \DB::table('plans')->where('plan_amount','=',$user->plan)->first();
    ?>
                <?php $day = $data_plan->no_of_days; $amount =0; $counter = 0; ?>
                <?php for($i =1; $i <= $data_plan->no_of_days; $i++): ?>
                <?php 
                  

                  $counter=$counter+3;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                  /*if(date('l', strtotime($date))=='Saturday' || date('l', strtotime($date))=='Sunday')
                  {
                    $i--;
                    continue;
                    //$amount = $amount-400;
                  }*/
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day-1;
                      $amount = $amount+$data_plan->daily;
                      
                  }
                  
                ?>
                <?php endfor; ?>
                
                <?php if($user->is_active==2): ?>
              <h3><?php echo e($amount); ?></sup></h3>
            
              
               <?php elseif($user->is_active==0): ?>
                     <h3>You are Block</h3>
              <?php else: ?>
              <h3>Inactive</h3>
                <?php endif; ?>
                 
                 <p>Growth Income</p>
             
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">Total Growth Income<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
     
        <!-- ./col -->
      
    

       
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
                
              
                
                
                
                 
                 
                <?php $day = $data_plan->no_of_days; $amount_daily =0; $counter = 0; ?>
                <?php for($i =1; $i <= $data_plan->no_of_days; $i++): ?>
                <?php 
                  

                  $counter=$counter+3;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                  /*if(date('l', strtotime($date))=='Saturday' || date('l', strtotime($date))=='Sunday')
                  {
                    $i--;
                    continue;
                    //$amount = $amount-400;
                  }*/
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day-1;
                      $amount_daily = $amount_daily+$data_plan->daily;
                      
                  }
                  
                ?>
                <?php endfor; ?>
                
                
                  
                 
                 
            
                
                <?php if($user->is_active==2): ?>
                
                <?php if($amount_daily>=5000): ?>
                  <h3>5000</sup></h3>
              
                <?php else: ?>
                  <h3>0</sup></h3>
                <?php endif; ?>
               <?php elseif($user->is_active==0): ?>
                     <h3>Block</h3>
              <?php else: ?>
              <h3>Inactive</h3>
                <?php endif; ?>

              <p>1st GH Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">1st GH Income<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

    


      <?php

      $total_direct = \DB::table('users')->where('spencer_id','=',$user->email)->where('is_active','=','1')->count();        
       ?>
         <div class="row">

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
             
               
                 <?php if($user->is_active==2 && $total_direct>='1'): ?>
               <?php if($amount_daily>=15000): ?>
                  <h3>5000</sup></h3>
              
                <?php else: ?>
                  <h3>0</sup></h3>
                <?php endif; ?>
               <?php elseif($user->is_active==0): ?>
                     <h3>Block</h3>
              <?php else: ?>
              <h3>Inactive</h3>
                <?php endif; ?>

              <p>2nd GH Income</p>
              <p>1 Direct Compulsary</p>
            </div>
           


            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">2nd GH<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>

       

 <!-- ./col -->



       <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
               <?php
                 $user = Sentinel::check();
                 $tran_data = \DB::table('transaction')->join('users', 'transaction.level_id', '=', 'users.email')->where(['reciver_id'=>$user->email])->where(['transaction.generator'=>'system'])->where('transaction.activity_reason','=','level')->select('transaction.level_id as sender_id','transaction.reciver_id','transaction.id as trans_id','users.id as user_sender_id','users.is_active','transaction.date','transaction.approval','transaction.generator','transaction.amount')->get();
                 
                 $amount=0;
                 ?>
                 
                 <?php foreach($tran_data as $key=>$value): ?>
                 
                <?php
                 if($value->is_active==2)
                 {
                 $amount+=$value->amount; 
                }
                 ?>
                 <?php endforeach; ?>
               
                <?php if($user->is_active==2): ?>
              <h3><?php echo e($amount); ?></h3>
              <?php elseif($user->is_active==0): ?>
                     <h3>Block</h3>
              <?php else: ?>
              <h3>Inactive</h3>
                <?php endif; ?>

              <p>Total Level Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">Level Income<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

      </div>
        
</div>
     
   
      <!-- /.row -->
      <!-- Main row -->
       <?php if($user->is_active==2 || $user->is_active==1): ?>
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12">
          <div class="row">
           
           
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Provide Help (PH)</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
            

               <div class="box-body" id="div_link" style="overflow-x:auto;">
         
              
              
              
              
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Send Link To</th>
                  <th>Amount</th>
                   <th>action</th>
                 <!-- <th>Mobile No.</th>-->
                 <!-- <th>Status</th>
                  <th>Action</th>-->
                </tr>
                </thead>
                  
              <tbody>
                <?php foreach($data_trans as $key=>$value): ?>
            <?php $trans_user_data = \DB::table('users')->where(['email'=>$value->reciver_id])->first();
            if(empty($trans_user_data->user_name))
            {
              continue;
            }
            ?>
                

                      <td><?php echo e($key+1); ?></td>
                      <td><?php echo e(isset($trans_user_data->user_name) ? $trans_user_data->user_name : "NA"); ?></td>
                      <td><?php echo e($value->amount); ?></td>
                      <td> <a class="btn btn-success" href="<?php echo e(url('/')); ?>/admin/view?id=<?php echo e(isset($trans_user_data->id) ? $trans_user_data->id : 'NA'); ?>&amt=<?php echo e($value->amount); ?>&tran_id=<?php echo e($value->id); ?>">Give Help</a></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
       </div>
       </div>
      
            
           
            
            
           
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Get help (GH)</h3>
                  <!-- tools box -->
                  <div class="box-body" style="overflow-x:auto;">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>User Id</th>
                  <th>amount</th>
                  <th>Action</th>
                  
                 <!-- <th>Mobile No.</th>-->
                 <!-- <th>Status</th>
                  <th>Action</th>-->
                </tr>
                </thead>
                   <?php 
                    $user = Sentinel::check();
                        $data = \DB::table('transaction')->where(['reciver_id'=>$user->email])->where('generator','<>','reciever')->where(['approval'=>'payment_done'])->get();
                    ?>
            <tbody>
                  <?php foreach($data as $key=>$value): ?>
                    <tr>
                      <?php $trans_user_data = \DB::table('users')->where(['email'=>$value->sender_id])->first();
            if(empty($trans_user_data->user_name))
            {
              continue;
            }
            ?>
                

                      <td><?php echo e($key+1); ?></td>
                      <td><?php echo e($value->sender_id); ?></td>
                      <td><?php echo e($value->amount); ?></td>
                      <td> <a class="btn btn-success" href="<?php echo e(url('/')); ?>/admin/view1?id=<?php echo e(isset($trans_user_data->id) ? $trans_user_data->id : 'NA'); ?>">Get Help</a></td>
                      
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
              </div>
            </div>
         
           
       </div>
    

        <!--  <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>
                   <h3 class="box-title">Rewards</h3>
                  </div>
                  
                  <li>1 Day Business - ₹25000  ( ₹ 2000 Reward) </li>
                  <li>2 Days Business - ₹50000 ( ₹5000 Reward)</li>
                  <li>4 Days Business - ₹100000 ( ₹10000 Reward )</li>
                  <li>10 Days Business - ₹500000 ( ₹50000 Reward)</li>
                  </div>
                  </div> -->
            </div>
        </section>
        <!-- /.Left col -->
      </div>
      <?php endif; ?>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
  alert("Copied the text: " + copyText.value);
}
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>