                

<?php $__env->startSection('main_content'); ?>

  <!-- START MAIN -->
  <div id="main">
      <!-- START WRAPPER -->
      <div class="wrapper">         

          <!-- //////////////////////////////////////////////////////////////////////////// -->

          <!-- START CONTENT -->
          <section id="content">

              <!--start container-->
              <div class="container">

                  <!--card widgets start-->
                  <div id="card-widgets">
                    <div class="row" style="display: none;">
                      <!-- map-card -->
                      <div class="col s12 m12 l4">
                          <div class="map-card">
                              <div class="card">
                                  <div class="card-image waves-effect waves-block waves-light">
                                      <div id="map-canvas" data-lat="40.747688" data-lng="-74.004142"></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>  

                <div class="container">
                  <div class="row">
                    <div class="col s12 m12 l12">
                      <h5 class="breadcrumbs-title">Downline</h5>
                      <ol class="breadcrumbs">
                        <li><a href="<?php echo e(url('/customer/dashboard')); ?>">Dashboard</a>
                        </li>
                        <li><a href="#">Downline</a>
                        </li>
                        <li class="active">My Direct</li>
                      </ol>
                    </div>
                  </div>
                </div>

           <!--DataTables example-->
            <div id="table-datatables">
              
              <div class="row">
                <div class="col s12 m12 8">
                  <table id="data-table-simple" class="responsive-table display" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Id</th>
                            <th>Name</th>
                            <th>Join Date</th>
                            <th>Mobile No.</th>
                            <th>Package</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                 
                    <tbody>
                      <?php foreach($data as $key=>$user): ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($user['email']); ?></td>
                            <td><?php echo e($user['user_name']); ?></td>
                            <td><?php echo e(isset($user['joining_date']) ? $user['joining_date'] : "NA"); ?></td>
                            <td><?php echo e($user['mobile']); ?></td>
                            <td><i class="fa fa-inr"></i> <?php echo e($user['package']); ?></td>
                            <td><?php echo e(ucfirst($user['status'])); ?></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div> 
            <br>
            <div class="divider"></div> 
          
            <!--end container-->
          </section>
          <!-- END CONTENT -->

      </div>
      <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->
   

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('customer.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>