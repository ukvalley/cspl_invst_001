<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Grow Indian Register</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/plugins/iCheck/square/blue.css">

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style type="text/css">
     .parsley-required{
      color: red;
      list-style: none;
      margin-left: -37px;
    }
    .parsley-equalto{
      color: red; 
      list-style: none;
          margin-left: -37px;
    }
  </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
        <img src="<?php echo e(url('/')); ?>/images/growind.png" style="height: 75px;"><br>
    <a href="<?php echo e(url('/')); ?>/admin"><b>Registration</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Registration </p>

      <form class="login-form" method="post" action="<?php echo e(url('/')); ?>/admin/register_process" data-parsley-validate="">
      <?php echo e(csrf_field()); ?>

      <?php echo $__env->make('admin.layout._operation_status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="form-group has-feedback">
        <input id="username" name="username" class="form-control" placeholder="Name" type="text" required="true">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
         <input id="user_id" name="user_id" class="form-control" placeholder="User Id" type="text" required="true">
        <span class="glyphicon fa fa-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input id="sponcer_id" name="sponcer_id" class="form-control" onchange="check()" placeholder="Sponcer Id" type="test" value="<?php echo e(isset($_GET['sponcer_id']) ? $_GET['sponcer_id'] : ''); ?>" required="true">
        <span id="success_msg" style="color: green"></span>
        <span id="error_msg" style="color:red"></span>
        <span class="glyphicon fa fa-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
         <input id="password" name="password" class="form-control" placeholder="Password" type="password" required="true">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
         <input id="mobile" name="mobile" class="form-control" placeholder="Mobile" type="text" required="true">
<span class="glyphicon glyphicon-mobile form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
         <input id="email" name="email" class="form-control" placeholder="Email" type="text" required="true">
      </div>
      <div class="form-group has-feedback">
         <input id="ifsc" name="ifsc" class="form-control" placeholder="IFSC" type="text" required="true">
      </div>
      <div class="form-group has-feedback">
         <input id="bank_account_no" name="bank_account_no" class="form-control" placeholder="Bank Account No." type="text" required="true">
      </div>
      <div class="form-group has-feedback">
         <input id="branch" name="branch" class="form-control" placeholder="Branch" type="text" required="true">
      </div>
      <div class="form-group has-feedback">
         <input id="banck_name" name="banck_name" class="form-control" placeholder="Bank Name" type="text" required="true">
      </div>
      <div class="form-group has-feedback">
         <input id="paytm" name="paytm" class="form-control" placeholder="Paytm" type="text" >
      </div>
      <div class="form-group has-feedback">
         <input id="phonepe" name="phonepe" class="form-control" placeholder="Phonepe" type="text" >
      </div>
      <div class="form-group has-feedback">
         <input id="tez" name="tez" class="form-control" placeholder="Tez" type="text" >
      </div>
      <div class="form-group has-feedback">
         <input id="bhim_upi" name="bhim_upi" class="form-control" placeholder="Bhim UPI" type="text" >
      </div>
      <div class="row">
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Register</button>
        </div>
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?php echo e(url('/')); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(url('/')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo e(url('/')); ?>/bower_components/parsley.js"></script>
<script type="text/javascript">
   function check()
    {
       var sponcer_id = $('#sponcer_id').val();
       $.ajax({
              url: "<?php echo e(url('/check_sponcer1')); ?>",
              type: 'GET',
              data: {
                _method: 'GET',
                sponcer_id     : sponcer_id,
                _token:  '<?php echo e(csrf_token()); ?>'
              },
            success: function(response)
            {
              if(response.status == 'success')
              {
                $('#success_msg').text(response.name);
                $('#error_msg').text('');
              }
              else if(response.status == 'error')
              {
                $('#success_msg').text('');
                $('#error_msg').text('Sponcer id is invalid');
              }
              else
              {
                $('#success_msg').text('');
                $('#error_msg').text('Sponcer id is invalid');
              }
            }
            });
    }
</script>
<script>

$(document).ready(function(){
     setInterval(function(){  location.reload(); }, 380000);
});
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>
