 $("#n").click(function () {
            if ($(this).is(":checked")) {
            	var nashik = $("#n").val();
            	
            	$("#m1").html(nashik);
                $("#m1").show();
                $("#m11").show();
            } else {
               
            }
        });



            $("#m").click(function () {
            if ($(this).is(":checked")) {
            	var nashik = $("#m").val();

            	$("#m1").html(nashik);
                $("#m1").show();
                $("#m11").show();
            } else {
               
            }
        });