                

<?php $__env->startSection('main_content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
                <?php $day = 20; $amount =0; $counter = 0; ?>
                <?php for($i =1; $i <= 20; $i++): ?>
                <?php 
                  $user = Sentinel::check();
                  $counter++;
                  if($user->joining_date==null)
                  {
                    break;
                  }
                  $date = date('d-m-Y', strtotime($user->joining_date. ' + '.$counter.' day'));
               
                  if(date('l', strtotime($date))=='Saturday' || date('l', strtotime($date))=='Sunday')
                  {
                    $i--;
                    continue;
                    //$amount = $amount-400;
                  }
                  if(strtotime($date)<=strtotime(date('d-m-Y')))
                  {
                      $day = $day-1;
                  }
                  
                ?>
                <?php endfor; ?>
                <?php $amt =  4000-(200*(20-$day)) ?>
                <?php if($user->is_active==1): ?>
                    <h3>4000</h3>

                   
                    <?php if($amt<=0): ?>
                    <a href="<?php echo e(url('/')); ?>/admin/recommit?email=<?php echo e($user->email); ?>" class="btn bg-red">Recommitment</a>
                    <?php else: ?>
                     <p>Commitment</p>
                    <?php endif; ?>
                <?php else: ?>
                     <h3>Block</h3>
                      <p>Commitment</p>
                <?php endif; ?>
              
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer"><?php echo e($day); ?> Day Left <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
                <?php
                 $user = Sentinel::check();
                 $count = \DB::table('transaction')->where(['reciver_id'=>$user->email])->where(['generator'=>'system'])->where(['activity_reason'=>'work'])->where(['approval'=>'completed'])->count();
                ?>
                <?php if($user->is_active==1): ?>
              <h3><?php echo e($count*400); ?></sup></h3>
               <?php else: ?>
                     <h3>Block</h3>
                <?php endif; ?>

              <p>Total Work Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
               <?php if($user->is_active==1): ?>
              <h3>400</h3>
              <?php else: ?>
                     <h3>Block</h3>
                <?php endif; ?>

              <p>Today's Growth Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
               <?php
                 $count1 = \DB::table('transaction')->where(['reciver_id'=>$user->email])->where(['generator'=>'system'])->where(['date'=>date('Y-m-d')])->where(['activity_reason'=>'work'])->where(['approval'=>'completed'])->count();
                ?>
                <?php if($user->is_active==1): ?>
              <h3><?php echo e($count1*400); ?></h3>
              <?php else: ?>
                     <h3>Block</h3>
                <?php endif; ?>

              <p>Today's Work Income</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
       <?php if($user->is_active==1): ?>
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="row">
           
           
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Link Details(Give)</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body" style="background-color: #9C27B0;color: white">
                  <div class="col-md-12" >
                    <div class="row">
                      <script>
                                  // Set the date we're counting down to
                                  //var countDownDate = new Date("April 17, 2018 11:39:25").getTime();
                                  <?php if($user->recommitment_at!=null): ?>
                                   //alert('<?php echo(date("M d, Y H:i:s",  strtotime("+"."1 days", strtotime($user->recommitment_at)))); ?>');
                                  var countDownDate = new Date('<?php echo(date("M d, Y H:i:s",  strtotime("+"."48 hours", strtotime($user->recommitment_at)))); ?>').getTime();
                                  <?php else: ?>
                                  //alert('<?php echo(date("M d, Y H:i:s",  strtotime("+"."1 days", strtotime($user->created_at)))); ?>');
                                  var countDownDate = new Date('<?php echo(date("M d, Y H:i:s",  strtotime("+"."48 hours", strtotime($user->created_at)))); ?>').getTime();
                                  <?php endif; ?>

                                  // Update the count down every 1 second
                                  var x = setInterval(function() {

                                      // Get todays date and time
                                      var now = new Date().getTime();
                                      
                                      // Find the distance between now an the count down date
                                      var distance = countDownDate - now;
                                      
                                      // Time calculations for days, hours, minutes and seconds
                                      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                      var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                                      
                                      // Output the result in an element with id="demo"
                                      document.getElementById("demo").innerHTML =  days + "D " + hours + "H "
                                      + minutes + "M " + seconds + "S ";
                                      
                                      // If the count down is over, write some text 
                                      if (distance < 0) {
                                          clearInterval(x);
                                          document.getElementById("demo").innerHTML = "Commitment Done";
                                         // $('#div_link').remove();
                                      }
                                  }, 1000);
                                </script>
<?php if($user->join_count<10): ?>
                      <div class="col-md-12">Expiration Remain:<span class="task-card-date" style="color: white;font-size: 20px" id="demo"></span></div>
<?php endif; ?>
                      <div class="col-md-6">User Name:  <?php echo e(isset($user->user_name) ? $user->user_name : 'NA'); ?></div>
                      <div class="col-md-6">User Id: <?php echo e(isset($user->email) ? $user->email : 'NA'); ?></div>
                      <div class="col-md-6">Created Date: <?php echo e(isset($user->created_at) ? $user->created_at : 'NA'); ?></div>
                    </div>
                   
                  </div>
                </div>

                <div class="box-body" id="div_link">
                    <?php foreach($data_trans as $key=>$value): ?>
            <?php $trans_user_data = \DB::table('users')->where(['email'=>$value->reciver_id])->first();
            if(empty($trans_user_data->user_name))
            {
              continue;
            }
            ?>
                  <div class="col-md-12">
                       <div class="form-group" style="background-color: #00FF00; border-radius: 25px;">
                      <i class="fa fa-arrow-circle-o-right" style="font-size: 25px;margin-left: 2%"></i>
                        <span style="font-size: 20px;">Give Help</span><br>
                        <span style="font-size: 10px;margin-left: 5%"><?php echo e(isset($trans_user_data->user_name) ? $trans_user_data->user_name : "NA"); ?></span>
                        <span style="font-size: 10px;margin-left: 20%">Amount: <i class="fa fa-inr"></i> 400</span>
                       <a class="btn" style="    margin-top: -2%;
    margin-right: 2%;
    margin-bottom: -2%;
    margin-left: -2%;;background-color: white;float: right;font-size: 10px;padding: 0px 12px;" href="<?php echo e(url('/')); ?>/admin/view?id=<?php echo e(isset($trans_user_data->id) ? $trans_user_data->id : 'NA'); ?>">Details</a>
                    </div>
                  </div>
                   <?php endforeach; ?>
                </div>
              </div>
            </div>
            
            
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Refer Friend</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body">
                    URL: <?php echo e(url('/')."/admin/registration?sponcer_id=".$user->email); ?>

                </div>
              </div>
            </div>
            
            
           
            <div class="col-md-6">
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>

                  <h3 class="box-title">Link Details(Get)</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                            title="Remove">
                      <i class="fa fa-times"></i></button>
                  </div>
                  <!-- /. tools -->
                </div>
                <div class="box-body">
                    <?php 
                        $get_trans = \DB::table('transaction')->where(['reciver_id'=>$user->email])->get();
                    ?>
                    Click Here To Receive Link <a class="btn btn-info" href="<?php echo e(url('/')); ?>/admin/get_link">Click</a>
                </div>
              </div>
            </div>
          
           
          </div>

        </section>
        <!-- /.Left col -->
      </div>
      <?php endif; ?>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>